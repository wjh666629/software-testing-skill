# Changelog

## v1.0.0 — 2026-09-19

First publishable release. Fully run on a real project (pure-frontend data-visualization project, 303 medical records):
35 cases, 33 executed, 12 defects found (S1×1 / S2×3 / S3×6 / S4×2).

**Added**
- W1~W6 six-stage workflow (testability assessment → plan → cases → automation → defect → report) with a trigger-routing table
- Seven ground rules, including "never fabricate execution results" and "degrade when the stack mismatches"
- 5 references: case-design methods, pytest conventions, pure-frontend Node+jsdom path, defect grading, test-point checklist
- 4 deliverable templates: case set / test plan / test report / defect report
- 2 runnable scripts: `scaffold_pytest.py` (generate a pytest project), `cases_to_xlsx.py` (case table → Excel, degrades to CSV when openpyxl is missing)
- Real case `examples/biomed-frontend-case/`

**Known limitations**
- Validated on only 1 real project so far; Java/JS backend projects and large codebases not yet covered
- The pure-frontend path depends on jsdom; layout/rendering assertions need a real browser
- The English edition (v1.0.0-en) is a separate package, maintained in sync with the main package

**Next steps**
- Add Java (JUnit5/TestNG) and JS (Playwright/Jest) scaffold scripts
- Add 2~3 validation records on projects of different sizes
- Add dedicated performance and security test templates
