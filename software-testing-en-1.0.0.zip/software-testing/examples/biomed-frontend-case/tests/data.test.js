/**
 * Biomedical big-data analysis platform — data-layer tests
 * Run: node tests/data.test.js
 * Zero dependencies; loads the SUT data.js directly via vm
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = process.env.SRC_DIR
  || '<path-to-sut>';
const NODE = path.posix || {};

// Load the SUT script
const code = fs.readFileSync(path.join(SRC, 'data.js'), 'utf8');
const ctx = vm.createContext({ console });
vm.runInContext(code, ctx);
const md = vm.runInContext('medicalData', ctx);

let pass = 0, fail = 0;
const failures = [];

function check(id, name, fn) {
  try {
    const detail = fn();
    pass++;
    console.log(`PASS  ${id}  ${name}${detail ? '  -> ' + detail : ''}`);
  } catch (e) {
    fail++;
    failures.push({ id, name, msg: e.message });
    console.log(`FAIL  ${id}  ${name}\n        ${e.message}`);
  }
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }

console.log('=== Data-layer tests ===\n');

// ---------- Basic statistics ----------
check('TC-D-01', 'Patient total is 303', () => {
  const total = md.patients.length;
  assert(total === 303, `expected 303, got ${total}`);
  return `${total} records`;
});

check('TC-D-02', 'Disease-distribution sum == patient total', () => {
  const dist = md.getDiseaseDistribution();
  const sum = Object.values(dist).reduce((a, b) => a + b, 0);
  assert(sum === md.patients.length, `distribution sum ${sum} != total ${md.patients.length}`);
  return JSON.stringify(dist);
});

check('TC-D-03', 'Gender-distribution sum == patient total', () => {
  const g = md.getGenderDistribution();
  assert(g.male + g.female === md.patients.length,
    `male ${g.male} + female ${g.female} != ${md.patients.length}`);
  return `male ${g.male} / female ${g.female}`;
});

check('TC-D-04', 'Age-distribution sum == patient total', () => {
  const a = md.getAgeDistribution();
  const sum = Object.values(a).reduce((x, y) => x + y, 0);
  assert(sum === md.patients.length, `age-group sum ${sum} != ${md.patients.length}`);
  return JSON.stringify(a);
});

check('TC-D-05', 'getStats fields complete and correctly typed', () => {
  const s = md.getStats();
  ['totalPatients', 'avgAge', 'diseaseTypes', 'recoveryRate'].forEach(k =>
    assert(k in s, `missing field ${k}`));
  assert(Number.isFinite(s.avgAge), `avgAge not a number: ${s.avgAge}`);
  return JSON.stringify(s);
});

check('TC-D-06', 'recoveryRate formatted with percent sign and sane value', () => {
  const s = md.getStats();
  assert(typeof s.recoveryRate === 'string' && /^\d+%$/.test(s.recoveryRate),
    `recoveryRate format invalid: ${s.recoveryRate}`);
  return s.recoveryRate;
});

// ---------- Semantic correctness (expected to expose defects) ----------
check('TC-D-07', 'UI label "recovery rate" maps to a real field in the data', () => {
  const s = md.getStats();
  const hasRecoveryField = md.patients.some(p =>
    ['recovered', 'recovery', 'outcome'].some(k => k in p));
  assert(hasRecoveryField,
    `dataset has no "recovery/outcome" field; "recovery rate ${s.recoveryRate}" is actually the share of target=0 (not diseased) = ${Math.round(md.patients.filter(p => p.target === 0).length / md.patients.length * 100)}%, label does not match data semantics`);
  return s.recoveryRate;
});

// ---------- Monthly trend (expected to expose defects) ----------
check('TC-D-08', 'getMonthlyTrends returns 12 months in correct order', () => {
  const t = md.getMonthlyTrends();
  assert(t.length === 12, `expected 12 months, got ${t.length}`);
  assert(t[0].month === '1月' && t[11].month === '12月',
    `month order wrong: ${t[0].month} ~ ${t[11].month}`);
  return t.map(x => x.month).join(',');
});

check('TC-D-09', 'Monthly-trend data is traceable to a time field in patient records', () => {
  const hasTimeField = md.patients.some(p =>
    ['date', 'month', 'visitDate', 'time'].some(k => k in p));
  assert(hasTimeField,
    'patient records have no time field (date/month/visitDate); "disease trend" and "monthly patient change" have no data source — they are inferred from diseases total / 12');
  return 'time field exists';
});

check('TC-D-10', 'Same disease should differ across months, not be a total/12 copy', () => {
  const t = md.getMonthlyTrends();
  const series = t.map(x => x['无心脏病']);
  const unique = [...new Set(series)];
  assert(unique.length > 1,
    `"no heart disease" 12-month values are [${series.join(',')}], only ${unique.length} distinct: no real time variation, derived from baseValue/12`);
  return unique.length + ' distinct values';
});

check('TC-D-11', 'Heatmap values should vary by month (app.js initHeatmap uses count/12)', () => {
  const counts = md.patients.reduce((acc, p) => {
    acc[p.target] = (acc[p.target] || 0) + 1; return acc;
  }, {});
  const row = [];
  for (let m = 0; m < 12; m++) row.push(Math.floor((counts[0] || 0) / 12));
  const unique = [...new Set(row)];
  assert(unique.length > 1,
    `heatmap "no heart disease" row is constant [${row.join(',')}] across 12 cells: whole row same color, represents no monthly difference`);
  return row.join(',');
});

// ---------- Data integrity ----------
check('TC-D-12', 'Key fields have no null/undefined/NaN', () => {
  const fields = ['age', 'sex', 'trestbps', 'chol', 'thalach', 'target'];
  const bad = [];
  md.patients.forEach((p, i) => {
    fields.forEach(f => {
      const v = p[f];
      if (v === null || v === undefined || (typeof v === 'number' && Number.isNaN(v))) {
        bad.push(`id=${p.id} field ${f}=${v}`);
      }
    });
  });
  assert(bad.length === 0, `found ${bad.length} anomalies: ${bad.slice(0, 5).join('; ')}`);
  return `${md.patients.length} records validated`;
});

check('TC-D-13', 'Numeric fields within medically sane ranges', () => {
  const bad = [];
  md.patients.forEach(p => {
    if (p.age < 0 || p.age > 120) bad.push(`id=${p.id} age=${p.age}`);
    if (p.trestbps < 60 || p.trestbps > 260) bad.push(`id=${p.id} trestbps=${p.trestbps}`);
    if (p.chol < 0 || p.chol > 700) bad.push(`id=${p.id} chol=${p.chol}`);
    if (p.thalach < 40 || p.thalach > 220) bad.push(`id=${p.id} thalach=${p.thalach}`);
  });
  assert(bad.length === 0, `out of range ${bad.length}: ${bad.slice(0, 5).join('; ')}`);
  return 'all within sane ranges';
});

check('TC-D-14', 'target values are only 0~4', () => {
  const bad = md.patients.filter(p => ![0, 1, 2, 3, 4].includes(p.target));
  assert(bad.length === 0, `invalid target: ${bad.slice(0, 3).map(p => p.id + '=' + p.target).join(', ')}`);
  return 'valid';
});

// ---------- Filter logic (equivalent impl of app.js getFilteredData) ----------
check('TC-D-15', 'Filter by disease level yields correct counts', () => {
  const results = {};
  [0, 1, 2, 3, 4].forEach(lv => {
    results[lv] = md.patients.filter(p => p.target === lv).length;
  });
  const sum = Object.values(results).reduce((a, b) => a + b, 0);
  assert(sum === md.patients.length, `sum per level ${sum} != ${md.patients.length}`);
  return JSON.stringify(results);
});

check('TC-D-16', 'Scatter plot slice(0,100) truncates data without warning', () => {
  const all = md.patients.length;
  const shown = Math.min(all, 100);
  const lost = all - shown;
  assert(lost === 0,
    `scatter plot renders only first ${shown} records, drops ${lost} (${(lost / all * 100).toFixed(0)}%), with no "sampled / showing first N" note on the page`);
  return `showing ${shown}/${all}`;
});

check('TC-D-17', 'After filtering "critical heart disease", scatter sample is large enough to support conclusions', () => {
  const n = md.patients.filter(p => p.target === 4).length;
  assert(n >= 30, `critical heart disease only ${n} cases, sample too small, chart conclusion unreliable and unwarned`);
  return `${n} cases`;
});

// ---------- Idempotency ----------
check('TC-D-18', 'Calling init() repeatedly should not duplicate trend data', () => {
  const before = md.diseaseTrends.length;
  md.init();
  const after = md.diseaseTrends.length;
  assert(before === after, `after second init() diseaseTrends grew from ${before} to ${after}, data appended again`);
  return `${before} records`;
});

console.log(`\n=== Summary: ${pass} passed, ${fail} failed ===`);
if (fail) {
  console.log('\nFailed cases (see defect report):');
  failures.forEach(f => console.log(`  ${f.id} ${f.name}\n      ${f.msg}`));
}
process.exit(fail ? 1 : 0);
