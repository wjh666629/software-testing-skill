/**
 * Biomedical big-data analysis platform — DOM / interaction-layer tests
 * Run: NODE_PATH=<workspace>/node_modules node tests/dom.test.js
 * Deps: jsdom (Chart.js and canvas stubbed, no network)
 */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const SRC = process.env.SRC_DIR
  || '<path-to-sut>';

const html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true });
const win = dom.window;
const doc = win.document;

// ---- Stub: canvas / Chart.js / scrollIntoView ----
win.HTMLCanvasElement.prototype.getContext = () => ({
  canvas: { width: 600, height: 400 },
  clearRect() {}, save() {}, restore() {}, beginPath() {}, measureText: () => ({ width: 10 }),
});
win.__chartInstances = [];
win.Chart = function (ctx, config) {
  this.ctx = ctx;
  this.data = config.data;
  this.options = config.options;
  this.type = config.type;
  this.updateCount = 0;
  this.update = function () { this.updateCount++; };
  win.__chartInstances.push(this);
};
win.Element.prototype.scrollIntoView = function () { win.__lastScrolled = this; };

// ---- Inject SUT scripts ----
// Note: const/let inside eval are eval-scope private and do NOT attach to window,
// so explicitly export at the end of the same eval for later scripts and assertions to access.
function loadScript(file, exports) {
  const code = fs.readFileSync(path.join(SRC, file), 'utf8');
  const tail = exports.map(n => `;window.${n} = ${n};`).join('');
  win.eval(code + tail);
}
loadScript('data.js', ['medicalData', 'heartDiseaseData']);
loadScript('app.js', ['charts', 'currentFilters']);
doc.dispatchEvent(new win.Event('DOMContentLoaded'));

const E = expr => win.eval(expr);

let pass = 0, fail = 0;
const failures = [];
function check(id, name, fn) {
  try {
    const detail = fn();
    pass++;
    console.log(`PASS  ${id}  ${name}${detail ? '  -> ' + detail : ''}`);
  } catch (e) {
    fail++;
    failures.push({ id, name, msg: e.message });
    console.log(`FAIL  ${id}  ${name}\n        ${e.message}`);
  }
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const click = el => el.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
const change = el => el.dispatchEvent(new win.Event('change', { bubbles: true }));

const sleep = ms => new Promise(r => setTimeout(r, ms));

console.log('=== DOM / interaction-layer tests ===\n');

async function main() {
await sleep(1800);   // wait for stat-card number animation (50 steps * 30ms) to finish

check('TC-U-01', 'Dashboard is the active page after load', () => {
  assert(doc.getElementById('dashboard').classList.contains('active'),
    'dashboard not active');
  return 'dashboard.active';
});

check('TC-U-02', 'All four stat cards rendered (not initial 0)', () => {
  const ids = ['totalPatients', 'avgAge', 'diseaseTypes', 'recoveryRate'];
  const vals = ids.map(i => doc.getElementById(i).textContent);
  assert(!vals.includes('0'), `unrendered card: ${JSON.stringify(vals)}`);
  return vals.join(' / ');
});

check('TC-U-03', 'Clicking nav switches to the analysis page', () => {
  click(doc.querySelector('.nav-item[data-page="analysis"]'));
  assert(doc.getElementById('analysis').classList.contains('active'),
    'analysis page not active');
  assert(!doc.getElementById('dashboard').classList.contains('active'),
    'dashboard not deactivated');
  return 'switch succeeded';
});

check('TC-U-04', 'Charts created on first entry to analysis page', () => {
  const n = win.__chartInstances.length;
  assert(n >= 8, `chart instances ${n}, expected >=8 (4 dashboard + 4 analysis)`);
  return `${n} chart instances`;
});

check('TC-U-05', 'No duplicate ids in HTML', () => {
  const ids = [...doc.querySelectorAll('[id]')].map(el => el.id);
  const dup = ids.filter((v, i) => ids.indexOf(v) !== i);
  assert(dup.length === 0,
    `duplicate ids: ${[...new Set(dup)].join(', ')} (<section id="analysis"> collides with report <article id="analysis">)`);
  return `${ids.length} ids all unique`;
});

check('TC-U-06', 'Report sidebar "5. Data analysis & experiment" anchor points to the report section', () => {
  const el = doc.getElementById('analysis');
  assert(el.tagName === 'ARTICLE',
    `getElementById('analysis') hits <${el.tagName.toLowerCase()}> (page section), not report article; anchor jump broken`);
  return 'hits report section';
});

check('TC-U-07', 'Clicking report sidebar nav item highlights and scrolls to the section', () => {
  const navItems = [...doc.querySelectorAll('.report-nav-item')];
  const target = navItems.find(a => a.getAttribute('href') === '#conclusion');
  click(target);
  assert(target.classList.contains('active'), 'nav item not highlighted after click');
  const scrolled = win.__lastScrolled;
  assert(scrolled && scrolled.id === 'conclusion',
    `scrollIntoView target is ${scrolled ? scrolled.id : 'null'}, expected conclusion`);
  return 'highlight + scroll correct';
});

check('TC-U-08', 'Scatter and cholesterol charts refresh together after changing "disease severity" filter', () => {
  const before = E('charts.bpHeartChart.updateCount');
  const sel = doc.getElementById('diseaseFilter');
  sel.value = '4';
  change(sel);
  const after = E('charts.bpHeartChart.updateCount');
  assert(after > before, `scatter not refreshed (updateCount ${before} -> ${after})`);
  return `updateCount ${before} -> ${after}`;
});

check('TC-U-09', 'Scatter point count matches filter result (14 critical-heart cases)', () => {
  const pts = E('charts.bpHeartChart.data.datasets[0].data.length');
  assert(pts === 14, `scatter renders ${pts} points, expected 14`);
  return `${pts} points`;
});

check('TC-U-10', 'Heatmap refreshes together after filter change', () => {
  const cellsBefore = [...doc.querySelectorAll('.heatmap-cell')].map(c => c.textContent).join(',');
  const sel = doc.getElementById('diseaseFilter');
  sel.value = '0';
  change(sel);
  const cellsAfter = [...doc.querySelectorAll('.heatmap-cell')].map(c => c.textContent).join(',');
  assert(cellsBefore !== cellsAfter,
    `heatmap unchanged after filter, identical before/after (first 20 chars: ${cellsBefore.slice(0, 20)}...)`);
  return 'refreshed together';
});

check('TC-U-11', 'Heatmap values truly reflect month differences (not whole-row same value)', () => {
  const cells = [...doc.querySelectorAll('.heatmap-cell')].map(c => c.textContent);
  assert(cells.length === 60, `heatmap cells ${cells.length}, expected 60 (5 diseases x 12 months)`);
  const firstRow = cells.slice(0, 12);
  const uniq = [...new Set(firstRow)];
  assert(uniq.length > 1,
    `first row 12 cells constant [${firstRow.join(',')}], whole row same color, no month difference`);
  return `${uniq.length} distinct values`;
});

check('TC-U-12', 'Monthly chart refreshes after changing "time range"', () => {
  const before = E('charts.monthlyChart.updateCount');
  const sel = doc.getElementById('timeRange');
  sel.value = '6';
  change(sel);
  const after = E('charts.monthlyChart.updateCount');
  assert(after > before, `monthly chart not refreshed (updateCount ${before} -> ${after})`);
  const labels = E('charts.monthlyChart.data.labels.length');
  assert(labels === 6, `time range 6 months, label count ${labels}, expected 6`);
  return `label count ${labels}`;
});

check('TC-U-13', 'Main nav items are keyboard-reachable (focusable element or role/tabindex)', () => {
  const items = [...doc.querySelectorAll('.nav-item')];
  const bad = items.filter(el =>
    el.tagName !== 'BUTTON' && el.tagName !== 'A'
    && !el.hasAttribute('tabindex') && !el.hasAttribute('role'));
  assert(bad.length === 0,
    `${bad.length}/${items.length} nav items are <li> with no tabindex/role, keyboard and screen-reader cannot focus them`);
  return `${items.length} nav items all focusable`;
});

check('TC-U-14', 'Key-finding cards rendered', () => {
  const cards = doc.querySelectorAll('.insight-card');
  assert(cards.length === 4, `key-finding cards ${cards.length}, expected 4`);
  return `${cards.length} cards`;
});

check('TC-U-15', 'Report metrics like "data coverage 89%" are backed by data', () => {
  const txt = doc.getElementById('report').textContent;
  const has = ['89%', '12', '5'].every(v => txt.includes(v));
  const stats = E('JSON.stringify(medicalData.getStats())');
  assert(!has || /89%/.test(stats),
    `report hardcodes metrics (data coverage 89%, analysis dims 12, prediction models 5), while getStats() returns ${stats}, cannot be mapped`);
  return 'metrics map to data';
});

  console.log(`\n=== Summary: ${pass} passed, ${fail} failed ===`);
  if (fail) {
    console.log('\nFailed cases (see defect report):');
    failures.forEach(f => console.log(`  ${f.id} ${f.name}\n      ${f.msg}`));
  }
  process.exit(fail ? 1 : 0);
}

main();
