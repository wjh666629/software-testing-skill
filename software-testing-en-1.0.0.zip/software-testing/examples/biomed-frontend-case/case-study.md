# Real Case: Full Test of a Pure-frontend Data-visualization Project

> This is what this skill produced on a real project, not a demo.
> It is also the origin of "why this skill needs a Node + jsdom fallback path".

## System under test

- Project: an IT festival entry from a university — a biomedical big-data analysis platform
- Form: pure static frontend — `index.html` + `app.js` + `data.js` + `styles.css`, no backend
- Data: UCI Cleveland heart-disease dataset, 303 patient records, 14 fields
- Charts: Chart.js (via CDN), 4 dashboard charts + 4 analysis-page charts + a heatmap

## Why pytest was not used

The project has not a single line of Python. Forcing pytest could only test the data file, not the page interactions.
So we followed the skill's degradation ground rule: **Node + jsdom**, stubbing canvas and Chart.js — no browser or network needed.

## Execution

```bash
node tests/data.test.js                 # data layer, zero deps, 18 cases
NODE_PATH=<node_modules> node tests/dom.test.js   # interaction layer, jsdom, 15 cases
```

Two pitfalls were hit along the way (now written into `references/frontend-testing.md`):
1. `const` inside `win.eval()` does not attach to window, so scripts can't see each other → must explicitly export at the end of the same eval
2. The stat cards render via animation, so assertions must wait 1800ms

## Results

| Layer | Cases | Pass | Fail |
|---|---|---|---|
| Data layer | 18 | 11 | 7 |
| Interaction layer | 15 | 9 | 6 |
| Environment (needs browser, not executed) | 2 | — | — |

Total: 35 cases, 20 passed / 13 failed / 2 not executed; 12 defects (S1×1, S2×3, S3×6, S4×2).

## The most valuable finding

**BUG-001 (S1, Critical): the time dimension was fabricated.**

The dataset has no time field at all, yet the page has three time-dimension charts: "disease trend analysis", "monthly patient change", and "health-metric heatmap".
`data.js` inferred 12 months of data with `Math.floor(total / 12 × seasonalFactor)`.

Measured evidence:

```
"No heart disease" 12-month values: [14,14,14,14,14,14,14,14,14,14,14,14]   <- only 1 distinct value
Heatmap first row, 12 cells:    [14,14,14,14,14,14,14,14,14,14,14,14]   <- whole row same color
12-month total 300, which also does not match the 303 patients
```

This is not a code bug, it is a data-design problem: **a dimension the dataset doesn't have was fabricated into a chart**.
Two more of the same kind: "56% recovery rate" is actually the share of target=0 (not diseased), and the dataset has no recovery field; the report's "data coverage 89%" is hardcoded in HTML.

## Other defects (excerpt)

| ID | Severity | Defect |
|---|---|---|
| BUG-002 | S2 | `id="analysis"` duplicated (page `<section>` collides with report `<article>`), 5th sidebar anchor broken |
| BUG-003 | S2 | "56% recovery rate" is conceptually wrong; should be "share not diseased" |
| BUG-004 | S2 | Scatter plot `slice(0,100)` silently drops 203 records (67%), no sampling hint |
| BUG-005 | S3 | Heatmap and "key findings" not refreshed after filter change; `updateAnalysis()` call missed |
| BUG-006 | S3 | 3 nav items are bare `<li>`, not Tab-focusable |
| BUG-010 | S3 | Chart.js loaded from public CDN, no local fallback (**not measured**, static-analysis conclusion) |

## What this case shows

1. **Strict automation testing is possible without Python** — jsdom stubs cover most interaction logic
2. **The most valuable defects are often not in the code** — the worst problem here was at the data source, which "make it work" testing can never catch
3. **Honestly marking not-executed items matters** — 2 layout-dependent cases were explicitly marked "NOT EXECUTED" and never folded into the pass rate

## Appendix: files in this directory

- `case-study.md` — this document
- `tests/data.test.js` — data-layer cases (runnable directly with `node`)
- `tests/dom.test.js` — interaction-layer cases (needs jsdom)
