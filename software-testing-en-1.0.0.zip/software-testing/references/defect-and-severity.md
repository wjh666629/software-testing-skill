# Defect Management and Report Conventions

## 1. Severity and Priority

### Severity
| Level | Definition | Typical scenario |
|---|---|---|
| S1 Critical | System crash / unusable / data corruption / money loss / security hole | service down, infinite loop, wrong amount, privilege escalation exposing others' data, injection vuln |
| S2 Serious | Main flow blocked with no workaround | core feature errors, login fails, order fails, data not persisted |
| S3 Normal | Function wrong but with a workaround, or non-main-flow issue | wrong secondary field, wrong copy, list sort inaccurate |
| S4 Minor | UX / UI issue, no functional impact | misaligned style, awkward copy, no loading indicator |

### Handling priority
- **P1 Immediate**: blocks release, fix within 24h (S1 / S2 main flow)
- **P2 High**: must fix this iteration
- **P3 Medium**: scheduled fix, can slip to next iteration
- **P4 Low**: fix when free, may become a requirement

> Severity describes "impact", priority describes "urgency". An S3 may still need P1 (e.g. externally promised copy) — note the reason.

## 2. Defect status flow

`New` → `Confirmed` → `Assigned` → `In Progress` → `Fixed` → `Ready for Test` → `Verified` → `Closed`

Side states:
- `Rejected`: not a defect / requirement changed / not reproducible → must state reason and notify the reporter
- `Deferred`: accepted but not fixed this iteration → must state the planned version
- `Reopened`: verification failed → back to In Progress, note the failing version and symptom

## 3. Required fields in a defect report

| Field | Requirement |
|---|---|
| Title | `[Module] condition + symptom`, one line to locate. Example: `[Order] Order with an expired coupon still not discounted at payment` |
| Environment | version/commit, environment (dev/test/prod), browser or client version, device |
| Preconditions | account state, data prep, switch config |
| Repro steps | numbered 1-2-3…, one action + concrete input per step |
| Actual result | paste error / screenshot / response body / log / DB actual value |
| Expected result | concrete description based on requirements |
| Repro rate | always / M of N / intermittent (state conditions) |
| Severity + priority | judge per the table above, with one sentence of reasoning |
| Impact scope | affected user group, related features, any temporary workaround |
| Attachments | screenshot, recording, API response, log snippet, HAR capture |

## 4. Principles of a good defect report

1. **Reproducible**: others can reproduce 100% by following the steps; intermittent defects state trigger conditions and frequency
2. **Minimal repro path**: drop irrelevant steps, keep only the shortest path that triggers the issue
3. **One defect per report**: split multiple issues for easier assignment and tracking
4. **Sufficient evidence**: error stack, request/response text, SQL, log timeline
5. **No subjective judgment**: write "response took 8s, over the 2s required by spec", not "very slow"
6. **Add root-cause hints** (bonus): initially locate module / line / config, but do not make absolute conclusions

## 5. Common RCA categories

- Requirement / design defect: unclear requirement, undefined boundary
- Logic error: condition, loop, state machine, concurrency control
- Data handling: type conversion, precision loss, time zone, encoding, null
- Interface / integration: inconsistent field contract, unhandled timeout, retry causing duplicates
- Config / environment: switch, canary, dependency version, data init
- Performance / capacity: slow SQL, no index, cache breakdown, exhausted connection pool
- Security: privilege escalation, injection, sensitive-info leak, unchecked redirect

## 6. Common "defect rejected" reasons (self-check before submitting)

- [ ] Not reproducible, and no environment / version / account given
- [ ] Actually a requirement not implemented, but absent from the requirement doc (file a requirement, not a defect)
- [ ] Symptom caused by dirty test-env data
- [ ] Duplicate of an existing defect (search first)
- [ ] Expected result has no basis (confirm with product first)
