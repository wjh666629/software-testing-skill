# Frontend Static-page Testing Path (fallback when there is no Python backend)

When the system under test is a pure-frontend project (static HTML + JS, no backend API, no Python environment), do not force pytest.
Use **Node built-in assertions + jsdom** to drive the page logic — runs in seconds, no browser or network needed.
When a browser is available, upgrade to Playwright for real rendering verification.

## 1. Selection guide

| Scenario | Approach |
|---|---|
| Pure static page / frontend component logic | Node + jsdom (this file) |
| Real rendering, layout, visual regression | Playwright + real browser |
| Has a backend API | Back to pytest + requests (`references/pytest-guide.md`) |

## 2. Environment

```bash
npm install jsdom          # install into an isolated workspace, not globally
NODE_PATH=<workspace>/node_modules node tests/dom.test.js
```

## 3. Scaffold template

```js
const fs = require('fs'), path = require('path');
const { JSDOM } = require('jsdom');
const SRC = process.env.SRC_DIR || '<path-to-sut>';

const dom = new JSDOM(fs.readFileSync(path.join(SRC, 'index.html'), 'utf8'),
  { runScripts: 'dangerously', pretendToBeVisual: true });
const win = dom.window, doc = win.document;

// 1) stub canvas (jsdom does not implement getContext)
win.HTMLCanvasElement.prototype.getContext = () => ({
  canvas: { width: 600, height: 400 }, clearRect(){}, save(){}, restore(){},
  beginPath(){}, measureText: () => ({ width: 10 }),
});

// 2) stub the chart lib: record instances and update count, to assert "did the chart refresh"
win.__chartInstances = [];
win.Chart = function (ctx, config) {
  this.data = config.data; this.options = config.options; this.type = config.type;
  this.updateCount = 0;
  this.update = function () { this.updateCount++; };
  win.__chartInstances.push(this);
};

// 3) jsdom does not implement scrollIntoView
win.Element.prototype.scrollIntoView = function () { win.__lastScrolled = this; };

// 4) key: const/let inside eval are eval-private scope and do NOT attach to window.
//    You must explicitly export at the end of the same eval, otherwise scripts can't see
//    each other and you get xxx is not defined.
function loadScript(file, exports) {
  const code = fs.readFileSync(path.join(SRC, file), 'utf8');
  win.eval(code + exports.map(n => `;window.${n} = ${n};`).join(''));
}
loadScript('data.js', ['medicalData']);
loadScript('app.js', ['charts', 'currentFilters']);
doc.dispatchEvent(new win.Event('DOMContentLoaded'));  // fire manually; jsdom already missed this event

const E = expr => win.eval(expr);   // read internal script variables
```

## 4. Three pitfalls you will hit

1. **`const`/`let` do not attach to window** (see `loadScript` above). `function` declarations attach, `const` does not.
2. **Animations are async**: before asserting number-roll / progress-bar, you must `await sleep(steps × interval + margin)`, or you read the initial value.
   `setInterval` really runs in jsdom, so you need `pretendToBeVisual: true`.
3. **jsdom has no layout engine**: `offsetTop`, `getBoundingClientRect`, and computed CSS `display` all return 0.
   Any assertion depending on layout (scroll highlight, element visibility, responsiveness) cannot be validated by jsdom — **mark it "NOT EXECUTED"** and route to manual / Playwright.

## 5. Zero-dependency data-layer quick check

If the SUT's JS is a pure data module (no DOM dependency), you don't even need jsdom:

```js
const vm = require('vm');
const ctx = vm.createContext({ console });
vm.runInContext(fs.readFileSync('data.js', 'utf8'), ctx);
const md = vm.runInContext('medicalData', ctx);   // read the value directly and assert
```

## 6. What to focus on in frontend

- Data lineage: every dimension in a chart maps to a real field in the source data (a dimension fabricated when the field is missing is the most severe class of defect)
- Linkage consistency: after a filter change, do **all** charts refresh (commonly one `update` call is missed)
- Silent truncation: is there a hint for sampling like `slice(0, N)`
- Hardcoded metrics: are the page's statistics computed, or hardcoded in HTML
- Keyboard reachability: bare `<li onclick>` elements can't be Tab-focused
- Dependency availability: does a CDN external link have a local fallback
- id uniqueness: duplicate ids make anchors / JS selectors hit the wrong element

## 7. Assertion output convention

Print `PASS/FAIL + case ID + name`; failure messages include the **actual value** ("actual 14, expected 30");
summarize pass/fail at the end and `process.exit(fail ? 1 : 0)` so it plugs into CI.
