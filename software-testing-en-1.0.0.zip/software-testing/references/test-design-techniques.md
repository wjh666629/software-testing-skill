# Test Case Design Methods and Writing Conventions

## 1. Method quick reference

### 1. Equivalence Partitioning
Divide the input domain into equivalence classes; pick one representative value per class.
- Valid equivalence class: inputs that conform to the spec
- Invalid equivalence class: inputs that violate the spec
- Steps: identify input conditions → split into valid/invalid classes → pick one representative per class → cover all classes

### 2. Boundary Value Analysis
Defects cluster at boundaries. For each boundary take `min-1 / min / min+1 / max-1 / max / max+1`.
- Applies to: numeric ranges, length limits, date intervals, pagination params, quantity caps
- Typical boundaries: 0, negative, empty, max, max+1, over-long string, precision (decimals)

### 3. Decision Table / Cause-Effect
Applies when multiple conditions combine to decide different outcomes (e.g. coupon stacking, risk rules, permission matrix).
- Steps: list all condition stubs and action stubs → compute 2^n combinations → merge redundant rules → one case per rule
- When the combination explodes, switch to pairwise (see below)

### 4. Orthogonal / Pairwise Combinatorial Testing
Applies when there are many parameters and the combination explodes. Guarantees every pair of parameter values is covered at least once; case count drops from n^k to ~k².
- By hand: first cover every single-parameter value, then fill in the pairwise combinations
- Tools: `pip install allpairspy`, or `itertools.product` for small exhaustive sets

### 5. Scenario / Business-flow Testing
Applies to end-to-end business flows. Draw basic flow + alternative flow + exceptional flow.
- Basic flow: the smoothest happy path
- Alternative flow: branches (e.g. different payment method)
- Exceptional flow: interruption, rollback, timeout, duplicate submission

### 6. State Transition
Applies to objects with an obvious state machine (order, ticket, approval flow).
- Cover: all valid transitions (forward) + all invalid transitions (negative, e.g. "cancelled" jumping straight to "completed")
- Checkpoints: does the state change persist to DB, does it notify, is it reversible

### 7. Error Guessing
List "most likely to break" points from experience: weak-network retry, oversell under concurrency, time zones, encoding (emoji/rare chars), money precision, double clicks, browser back button, expired cookie, out-of-order third-party callbacks.

## 2. Case writing conventions

### Standard fields

| Field | Notes | Example |
|---|---|---|
| Case ID | `TC-<MODULE>-<NNN>` | TC-LOGIN-001 |
| Module | Level-1 / Level-2 module | User Center / Login |
| Title | One line "condition + action + expectation" | Log in with correct account and password, redirect to home |
| Preconditions | State that must hold before execution | Active account test01 exists |
| Steps | Numbered steps, one action each | 1. Open login page 2. Enter… |
| Test data | Concrete input values, avoid "a correct value" | user=test01 / pwd=Test@123 |
| Expected | Decidable, observable; state the "page / API / DB" layers | Returns code=0; DB user.status=1; redirect /home |
| Priority | P0/P1/P2/P3, see below | P0 |
| Type | functional / boundary / exception / security / performance / compat / regression | boundary |
| Requirement | Requirement ID or user story | REQ-1024 |

### Priority definitions
- **P0 (smoke / blocker)**: core main flow, money-related, data safety; failure blocks release
- **P1 (high)**: main feature happy path + key exception branches
- **P2 (medium)**: secondary features, boundaries, UI detail, compatibility
- **P3 (low)**: UX polish, rarely triggered paths

### Discipline
1. **One case verifies one point** — even multiple assertions should serve the same expectation
2. **Expected must be decidable** — forbid "displays normally" / "runs fine"; write concrete values / status codes / DB fields
3. **Steps reproducible** — third-party deps, time, account state all stated clearly
4. **Cases independent** — no dependency on other cases' execution order; build preconditions with fixtures
5. **Positive/negative ratio** — for core features suggest 1:1.5, skewed toward negative

## 3. Coverage self-check
After producing the case set, self-check and fill gaps with this matrix:

- [ ] Every input param: valid equivalence / invalid equivalence / upper & lower boundary
- [ ] Every business-rule branch: at least one case per decision-table rule
- [ ] Every API: success / bad param / insufficient permission / not found / service error / timeout
- [ ] Every write op: idempotency, concurrency, rollback, data consistency
- [ ] Every state machine: all valid transitions + at least 3 invalid transitions
- [ ] Every list: empty / single / full page / over page / sort / filter / pagination boundary
- [ ] Permission matrix: logged-out / low privilege / same tenant / cross tenant / admin
- [ ] Regression cases: existing features affected by this change
