# Test-point Checklist

Walk each dimension line by line, marking `pass / fail / N/A / not tested`. Use for requirement review, case review, and pre-release sanity checks.

## 1. Functional correctness
- [ ] Main-flow happy path runs end to end (incl. callbacks, async jobs, scheduled tasks)
- [ ] Every input field: required/optional, type, length, format, default
- [ ] Business rules: condition combos, amount calc, discount stacking, inventory deduction, purchase limit
- [ ] Lists: empty / single / full page / over-page flip / sort / filter / fuzzy search hit
- [ ] Export / import: large volume, empty data, bad format, dirty-data tolerance
- [ ] CRUD: new record queryable after insert, related data handled on delete (physical / logical)
- [ ] State transitions: valid transitions + invalid transitions blocked
- [ ] Copy & hints: error codes map to accurate hints, no technical jargon exposed to users

## 2. Boundary and exception
- [ ] Zero, negative, max, over-long string, special chars (emoji, `<>&"'`, `\n`)
- [ ] Empty input, null, missing field, extra field
- [ ] File upload: 0 bytes, oversized, wrong format, special-char filename, duplicate name
- [ ] Dependency timeout / error code / empty / dirty data
- [ ] Network interruption retry, request timeout, weak network (UI / mobile)
- [ ] Request handling during restart / release, canary switch

## 3. Concurrency and idempotency
- [ ] Double click / double submit (frontend de-dup + backend idempotency key)
- [ ] Concurrent write to the same resource: oversell, balance overdraft, duplicate order
- [ ] Duplicate message consumption, out-of-order callback, callback replay
- [ ] Concurrent scheduled-job execution, long-task resume after interruption

## 4. Permission and security
- [ ] Logged-out access, expired / forged token
- [ ] Horizontal escalation: access / modify others' data
- [ ] Vertical escalation: low privilege calling admin APIs
- [ ] Multi-tenant isolation (cross-tenant data invisible)
- [ ] SQL injection, XSS, command injection, SSRF, template injection
- [ ] Upload file-type validation (no executable scripts)
- [ ] Sensitive info: logs / errors / API responses contain no plaintext password, token, ID, or phone
- [ ] Arbitrary URL redirect, CSRF, brute-forceable / bypassable captcha
- [ ] Second confirmation and audit log for important actions

## 5. Data and consistency
- [ ] Persisted fields correct (incl. creator, time, initial status)
- [ ] Related tables / redundant fields / cache consistent with DB
- [ ] Transaction rollback: no dirty data left on mid-way failure
- [ ] Money precision and rounding rules (double-check when money is involved)
- [ ] Time zone: store UTC vs local, cross-timezone display
- [ ] Legacy-data compatibility: old data doesn't error under new logic

## 6. Compatibility and config
- [ ] Browser / client version, OS (as needed)
- [ ] Screen size and resolution, dark mode
- [ ] i18n, long-text truncation, charset (UTF-8 end to end)
- [ ] Config / switch behaves correctly after toggle, sensible default

## 7. Performance and stability (smoke level)
- [ ] Single-API response time meets target (give measured p95 / max)
- [ ] Large list does not time out, has pagination
- [ ] No N+1 queries (slow SQL)
- [ ] No memory leak, exhausted connection pool, unreleased handles
- [ ] Rate limit / degrade / circuit breaker in effect

## 8. Observability
- [ ] Key paths have logs, incl. traceId
- [ ] Failures alert, errors are locatable
- [ ] Monitoring metrics exist (QPS, latency, error rate)

## 9. Testability challenge checklist (requirement review stage)
Ambiguous requirements are the main source of defects. At review, demand clarity on:
1. What are the input value ranges and boundaries? (e.g. "amount cap")
2. What is the user-perceived behavior of an exception / error branch?
3. If state is involved, is the state-machine diagram complete? How are invalid transitions handled?
4. What is the behavior under concurrency / duplicate operations?
5. Where does the data come from, where does it land, does it need rollback?
6. Permission scope: who can view, who can edit?
7. What are the conflicts with existing features? How big is the impact?
8. What are the performance / capacity expectations? (user count, data volume)
9. Does release need canary, switches, data migration, rollback plan?
