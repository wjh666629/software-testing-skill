# pytest Project Conventions and Code Templates

Default stack: Python + pytest. API tests use `requests`, UI tests use `playwright`, reports use `allure-pytest` or `pytest-html`.
If the system under test is a Java/JS stack, keep this file's **structure and strategy** but swap the syntax to JUnit5/TestNG or Playwright/Jest (see the mapping table at the end).

## 1. Recommended directory layout

```
tests/
├── conftest.py              # global fixtures: config, auth, client, data cleanup
├── pytest.ini               # or [tool.pytest.ini_options] in pyproject.toml
├── requirements.txt
├── api/                     # API layer: one file per business domain
│   ├── test_login.py
│   └── test_order.py
├── ui/                      # UI layer (Playwright)
│   └── test_checkout.py
├── data/                    # test data (yaml/json/csv)
│   └── cases_order.yaml
└── utils/
    ├── client.py            # wraps requests: base_url, timeout, retry, logging, auth header
    ├── assert_util.py       # common assertions: status code, JSON schema, DB checks
    └── db.py                # DB connection and assertions
```

Naming: files `test_*.py`, classes `Test*`, functions `test_*`; helpers must not start with `test`.

## 2. Recommended pytest.ini

```ini
[pytest]
testpaths = tests
addopts = -v --strict-markers --tb=short
markers =
    smoke: smoke cases, P0
    regression: regression cases
    api: API testing
    ui: UI testing
    slow: slow cases
    flaky: unstable cases, needs retry
```

Common plugins: `pytest-xdist` (parallel), `pytest-rerunfailures` (retry), `pytest-order` (ordering), `pytest-mock` (mock), `pytest-html` / `allure-pytest` (reports), `pytest-cov` (coverage).

## 3. Fixture organization

- Layer by scope: `session` (login state, global config) > `module` > `function` (independent data per case)
- Build test data with a fixture and **clean it up in teardown**, so cases are repeatable
- Env config from env vars; never hardcode domain / account / keys

```python
# conftest.py example
import os, pytest, requests

@pytest.fixture(scope="session")
def base_url():
    return os.getenv("BASE_URL", "http://localhost:8080")

@pytest.fixture(scope="session")
def token(base_url):
    r = requests.post(f"{base_url}/api/login",
                      json={"username": os.getenv("TEST_USER"),
                            "password": os.getenv("TEST_PWD")},
                      timeout=10)
    assert r.status_code == 200, r.text
    return r.json()["data"]["token"]

@pytest.fixture()
def api(base_url, token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}",
                      "Content-Type": "application/json"})
    s.base_url = base_url
    yield s
    s.close()
```

## 4. Parametrization and data-driven tests

```python
import pytest

@pytest.mark.api
@pytest.mark.parametrize("amount,expected_code", [
    (0, 0), (1, 0), (999999, 0),        # within boundary
    (-1, 400), (0.001, 400), ("abc", 400), (None, 400),  # invalid equivalence
])
def test_create_order_amount(api, amount, expected_code):
    r = api.post("/api/order", json={"amount": amount}, timeout=10)
    assert r.status_code == 200
    assert r.json()["code"] == expected_code
```

For large data sets, put case data in `data/*.yaml` and load it via `pytest.mark.parametrize`; use `ids=` in the parametrize to improve readability.

## 5. Assertion style

- Assert **down to the field**: `assert body["data"]["status"] == "PAID"` not `assert body`
- Assert status code first, then business code, then data structure, then DB
- Readable failure message: `assert r.json()["code"] == 0, f"expected 0, got {r.text}"`
- Use `jsonschema` for structure; missing fields are more common than wrong fields, so always check required fields exist

```python
def assert_ok(resp, timeout=10):
    assert resp.status_code == 200, f"HTTP {resp.status_code}: {resp.text}"
    body = resp.json()
    assert body.get("code") == 0, f"unexpected business code: {body}"
    return body["data"]
```

## 6. Seven API dimensions that must be tested (per endpoint)

1. Success response (field completeness, types, sorting, pagination)
2. Param validation: missing required, wrong type, over-long, out of range, special chars, SQL/XSS injection strings
3. Auth: no token, expired token, privilege escalation (others' resource)
4. Exception: resource not found, dependency timeout, service returns 5xx
5. Idempotency: duplicate submission of the same request (write endpoints)
6. Concurrency: concurrent writes to the same resource (lock / version / optimistic lock)
7. Data consistency: persisted fields, related tables, cache, messages all consistent

## 7. UI testing essentials (Playwright)

```python
from playwright.sync_api import expect

def test_login_success(page, base_url):
    page.goto(f"{base_url}/login")
    page.get_by_label("Username").fill("test01")
    page.get_by_label("Password").fill("Test@123")
    page.get_by_role("button", name="Log in").click()
    expect(page).to_have_url(f"{base_url}/home")
```

- Prefer semantic locators `get_by_role` / `get_by_label`; avoid XPath
- Use `expect()` auto-wait; never hard-wait with `time.sleep`
- One UI case verifies one business path; reuse login state via `storage_state`

## 8. Run and report

```bash
pip install -r requirements.txt
pytest -m smoke                       # smoke only
pytest -m "not slow" -n 4             # 4 parallel workers
pytest --reruns 2 --reruns-delay 1    # retry on failure (flaky only)
pytest --html=report.html --self-contained-html
pytest --alluredir=allure-results && allure serve allure-results
pytest --cov=src --cov-report=term-missing
```

CI integration: in GitHub Actions / GitLab CI, `pytest -m smoke` is the gate; all P0 green before merge.

## 9. Stability discipline (avoid flaky)

- No shared mutable state between cases; deep-copy shared data
- Isolate external deps with mocks or contract tests; keep only a few real e2e against third parties
- Time-related: inject a controllable clock, do not rely on `datetime.now()`
- Async results: poll-and-wait with timeout, not a fixed sleep
- Retry only for known-flaky cases, and tag with `flaky` to track them

## 10. Other stacks mapping

| Capability | Python | Java | JS/TS |
|---|---|---|---|
| Framework | pytest | JUnit5 / TestNG | Jest / Vitest / Playwright Test |
| Parametrize | `@pytest.mark.parametrize` | `@ParameterizedTest` | `test.each` |
| Setup/teardown | fixture | `@BeforeEach` / `@AfterEach` | `beforeEach` / `afterEach` |
| HTTP | requests / httpx | RestAssured | axios / fetch / supertest |
| UI | Playwright(python) | Selenium / Playwright(java) | Playwright |
| Mock | pytest-mock / responses | Mockito | jest.mock / msw |
| Report | allure-pytest / pytest-html | allure-junit5 / surefire | allure-playwright |
