#!/usr/bin/env python3
"""Scaffold a pytest automation project skeleton.

Usage:
    python scaffold_pytest.py --dir ./autotest --type api
    python scaffold_pytest.py --dir ./autotest --type both --force

Arguments:
    --dir    Target directory, defaults to ./autotest in the current dir
    --type   api | ui | both, defaults to both
    --force  Overwrite existing files (default skips, to avoid destroying existing content)
"""
import argparse
import os
import sys

PYTEST_INI = """[pytest]
testpaths = tests
addopts = -v --strict-markers --tb=short
markers =
    smoke: smoke cases, P0
    regression: regression cases
    api: API testing
    ui: UI testing
    slow: slow cases
    flaky: unstable cases, allow retry
"""

REQUIREMENTS_API = """pytest>=7.4
requests>=2.31
PyYAML>=6.0
jsonschema>=4.20
pytest-html>=4.1
pytest-xdist>=3.5
pytest-rerunfailures>=12.0
allure-pytest>=2.13
"""

REQUIREMENTS_UI = """playwright>=1.44
pytest-playwright>=0.4
"""

CONFTEST = '''"""Global fixtures: config, auth, HTTP client.

Env vars (see .env.example): BASE_URL / TEST_USER / TEST_PWD
"""
import os

import pytest
import requests


@pytest.fixture(scope="session")
def base_url():
    return os.getenv("BASE_URL", "http://localhost:8080")


@pytest.fixture(scope="session")
def token(base_url):
    """Log in to get a token, reused for the whole session."""
    resp = requests.post(
        f"{base_url}/api/login",
        json={
            "username": os.getenv("TEST_USER", ""),
            "password": os.getenv("TEST_PWD", ""),
        },
        timeout=10,
    )
    assert resp.status_code == 200, f"login failed: {resp.status_code} {resp.text}"
    return resp.json()["data"]["token"]


@pytest.fixture()
def api(base_url, token):
    """Authenticated HTTP session."""
    session = requests.Session()
    session.headers.update(
        {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    )
    session.base_url = base_url
    yield session
    session.close()
'''

CLIENT = '''"""HTTP client wrapper: unified timeout, logging, error handling."""
from typing import Any, Optional

import requests


class ApiClient:
    def __init__(self, base_url: str, token: str = "", timeout: int = 10):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"

    def request(self, method: str, path: str, **kwargs) -> requests.Response:
        url = path if path.startswith("http") else f"{self.base_url}{path}"
        kwargs.setdefault("timeout", self.timeout)
        resp = self.session.request(method, url, **kwargs)
        # On failure, log the context to help locate the problem
        if resp.status_code >= 500:
            print(f"[HTTP ERROR] {method} {url} -> {resp.status_code}: {resp.text[:500]}")
        return resp

    def get(self, path: str, params: Optional[dict] = None, **kwargs):
        return self.request("GET", path, params=params, **kwargs)

    def post(self, path: str, json: Any = None, **kwargs):
        return self.request("POST", path, json=json, **kwargs)

    def put(self, path: str, json: Any = None, **kwargs):
        return self.request("PUT", path, json=json, **kwargs)

    def delete(self, path: str, **kwargs):
        return self.request("DELETE", path, **kwargs)
'''

ASSERT_UTIL = '''"""Common assertion helpers: layered assertions with readable failure messages."""
from typing import Any, Iterable


def assert_http_ok(resp, timeout_msg: str = "") -> dict:
    """HTTP 200 + business code 0, returns data."""
    assert resp.status_code == 200, (
        f"HTTP {resp.status_code}, expected 200. Response: {resp.text[:500]} {timeout_msg}"
    )
    body = resp.json()
    assert body.get("code") == 0, f"business code {body.get('code')}, expected 0. Response: {body}"
    return body.get("data") or {}


def assert_keys(obj: dict, required: Iterable[str], optional: Iterable[str] = ()):
    """Validate response field completeness; missing fields are more common than wrong fields."""
    missing = [k for k in required if k not in obj]
    assert not missing, f"missing required fields: {missing}, actual fields: {list(obj)}"


def assert_pagination(data: dict, expected_page_size: int = 20):
    assert "total" in data and "list" in data, f"bad pagination structure: {list(data)}"
    assert len(data["list"]) <= expected_page_size, "page size exceeds limit"


def assert_db_equal(actual: Any, expected: Any, field: str = ""):
    assert actual == expected, f"DB field {field} expected {expected}, got {actual}"
'''

TEST_API = '''"""API test example: covers success / bad param / escalation / not found / idempotency."""
import pytest

from utils.assert_util import assert_http_ok, assert_keys

pytestmark = [pytest.mark.api]


@pytest.mark.smoke
def test_query_user_success(api):
    resp = api.get("/api/user/1")
    data = assert_http_ok(resp)
    assert_keys(data, ["id", "username", "status"])


@pytest.mark.parametrize("user_id,expected_code", [
    (1, 0),        # valid equivalence
    (0, 404),      # boundary: 0
    (-1, 404),     # boundary: negative
    ("abc", 400),  # wrong type
])
def test_query_user_invalid_param(api, user_id, expected_code):
    resp = api.get(f"/api/user/{user_id}")
    assert resp.json()["code"] == expected_code, resp.text


def test_query_user_without_token(base_url):
    """Unauthenticated access should be rejected."""
    import requests
    resp = requests.get(f"{base_url}/api/user/1", timeout=10)
    assert resp.status_code in (401, 403), f"accessible without auth: {resp.status_code}"


def test_create_order_idempotent(api):
    """Duplicate submission of the same request should produce only one record."""
    payload = {"skuId": 1001, "quantity": 1, "requestId": "req-test-001"}
    r1 = api.post("/api/order", json=payload)
    r2 = api.post("/api/order", json=payload)
    assert_http_ok(r1)
    assert_http_ok(r2)
    assert r1.json()["data"]["orderId"] == r2.json()["data"]["orderId"], "idempotency broken"
'''

TEST_UI = '''"""UI test example (Playwright)."""
import pytest
from playwright.sync_api import expect

pytestmark = [pytest.mark.ui]


@pytest.mark.smoke
def test_login_success(page, base_url):
    page.goto(f"{base_url}/login")
    page.get_by_label("Username").fill("test01")
    page.get_by_label("Password").fill("Test@123")
    page.get_by_role("button", name="Log in").click()
    expect(page).to_have_url(f"{base_url}/home")


def test_login_with_wrong_password(page, base_url):
    page.goto(f"{base_url}/login")
    page.get_by_label("Username").fill("test01")
    page.get_by_label("Password").fill("wrong_pwd")
    page.get_by_role("button", name="Log in").click()
    expect(page.get_by_text("wrong account or password")).to_be_visible()
'''

DATA_YAML = """# Data-driven case data example
# Load with yaml.safe_load, then pass to pytest.mark.parametrize
create_order_amount:
  - [0, 400]        # boundary: 0
  - [1, 0]          # valid
  - [999999, 0]     # valid
  - [-1, 400]       # invalid: negative
  - ["abc", 400]    # invalid: wrong type
"""

ENV_EXAMPLE = """BASE_URL=http://localhost:8080
TEST_USER=test01
TEST_PWD=Test@123
"""

README = """# Automation Test Project

## Install

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
{ui_install}cp .env.example .env   # fill in real config
```

## Run

```bash
pytest -m smoke                    # smoke only (P0)
pytest -m "api and not slow" -n 4  # API cases, 4 parallel workers
pytest --reruns 2 -m flaky         # retry unstable cases
pytest --html=report.html --self-contained-html
pytest --alluredir=allure-results && allure serve allure-results
```

## Layout

- `conftest.py` global fixtures (config, auth, client)
- `tests/api/` API cases, `tests/ui/` UI cases
- `utils/` client wrapper, common assertions, DB checks
- `data/` data-driven case data (yaml/json)

## Discipline

1. No shared mutable state between cases; build data with fixtures and clean up in teardown
2. Assert down to the field, include the actual response in failure messages
3. No time.sleep hard-wait; UI uses expect auto-wait
4. New cases must carry a marker; P0 carries smoke
"""


def write(path: str, content: str, force: bool) -> bool:
    """Write a file; skip if it exists and force is off. Return whether it was written."""
    if os.path.exists(path) and not force:
        return False
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return True


def main():
    parser = argparse.ArgumentParser(description="Scaffold a pytest automation project skeleton")
    parser.add_argument("--dir", default="autotest", help="target directory, default ./autotest")
    parser.add_argument("--type", choices=["api", "ui", "both"], default="both",
                        help="project type: api / ui / both")
    parser.add_argument("--force", action="store_true", help="overwrite existing files")
    args = parser.parse_args()

    root = os.path.abspath(args.dir)
    need_api = args.type in ("api", "both")
    need_ui = args.type in ("ui", "both")

    files = {
        os.path.join(root, "pytest.ini"): PYTEST_INI,
        os.path.join(root, "requirements.txt"):
            REQUIREMENTS_API + (REQUIREMENTS_UI if need_ui else ""),
        os.path.join(root, "conftest.py"): CONFTEST,
        os.path.join(root, ".env.example"): ENV_EXAMPLE,
        os.path.join(root, "utils", "client.py"): CLIENT,
        os.path.join(root, "utils", "assert_util.py"): ASSERT_UTIL,
        os.path.join(root, "data", "cases_example.yaml"): DATA_YAML,
        os.path.join(root, "README.md"): README.format(
            ui_install=("playwright install\n" if need_ui else "")
        ),
    }
    if need_api:
        files[os.path.join(root, "tests", "api", "test_example_api.py")] = TEST_API
    if need_ui:
        files[os.path.join(root, "tests", "ui", "test_example_ui.py")] = TEST_UI

    # Package __init__ not required; pytest imports via rootdir; keep utils importable
    files[os.path.join(root, "utils", "__init__.py")] = ""

    created, skipped = [], []
    for path, content in files.items():
        (created if write(path, content, args.force) else skipped).append(path)

    print(f"Project generated: {root}")
    print(f"Created {len(created)} file(s)" + (f", skipped {len(skipped)} existing file(s)" if skipped else ""))
    for p in sorted(created):
        print(f"  + {os.path.relpath(p, root)}")
    print("\nNext steps:")
    print(f"  cd {root}")
    print("  pip install -r requirements.txt")
    print("  cp .env.example .env && edit .env")
    print("  pytest -m smoke")
    return 0


if __name__ == "__main__":
    sys.exit(main())
