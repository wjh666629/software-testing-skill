#!/usr/bin/env python3
"""Convert a Markdown case set (tables) into an Excel case file.

Usage:
    python cases_to_xlsx.py cases.md                 # output cases.xlsx
    python cases_to_xlsx.py cases.md -o cases.xlsx

Behavior:
- Scan all Markdown tables in the md; each table becomes one sheet
- Sheet name comes from the nearest heading (##/###) above the table, truncated to 31 chars
- First row is the header; auto bold, freeze first row, enable filter, auto-fit column width
- If openpyxl is not installed, automatically degrade to CSV output with an install hint
"""
import argparse
import csv
import os
import re
import sys

MAX_SHEET_LEN = 31
ILLEGAL_SHEET_CHARS = r'[]:*?/\\'


def parse_markdown_tables(md_text: str):
    """Parse all tables in the md, return [(sheet_name, rows)]. rows is a 2D list."""
    tables = []
    current_heading = "Sheet1"
    lines = md_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        heading = re.match(r'^#{1,6}\s+(.*)', line)
        if heading:
            current_heading = heading.group(1).strip() or current_heading
            i += 1
            continue

        if line.strip().startswith("|") and i + 1 < len(lines) and \
                re.match(r'^\s*\|[\s:\-|]+\|\s*$', lines[i + 1]):
            header = split_row(line)
            i += 2  # skip header and separator rows
            rows = [header]
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            tables.append((current_heading, rows))
            continue
        i += 1
    return tables


def split_row(line: str):
    """Split `| a | b |` into ['a','b'], and strip <br> markers."""
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    return [re.sub(r'<br\s*/?>', '\n', c) for c in cells]


def safe_sheet_name(name: str, used: set):
    cleaned = "".join(ch for ch in name if ch not in ILLEGAL_SHEET_CHARS)
    cleaned = cleaned[:MAX_SHEET_LEN] or "Sheet"
    base = cleaned
    idx = 2
    while cleaned in used:
        suffix = f"_{idx}"
        cleaned = base[:MAX_SHEET_LEN - len(suffix)] + suffix
        idx += 1
    used.add(cleaned)
    return cleaned


def write_xlsx(tables, out_path):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        return False

    wb = Workbook()
    wb.remove(wb.active)
    used = set()
    head_fill = PatternFill("solid", fgColor="D9E1F2")
    head_font = Font(bold=True)

    for title, rows in tables:
        ws = wb.create_sheet(safe_sheet_name(title, used))
        if not rows:
            continue
        width = max(len(r) for r in rows)
        for r in rows:
            ws.append(list(r) + [""] * (width - len(r)))

        for cell in ws[1]:
            cell.fill = head_fill
            cell.font = head_font
            cell.alignment = Alignment(vertical="center", wrap_text=True)

        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)

        for col in range(1, width + 1):
            letter = get_column_letter(col)
            longest = max(
                (len(str(ws.cell(row=r, column=col).value or "")) for r in range(1, ws.max_row + 1)),
                default=8,
            )
            # Estimate CJK width as 2 chars; clamp to 12~50
            ws.column_dimensions[letter].width = min(max(longest * 1.2 + 2, 10), 50)

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:{get_column_letter(width)}{ws.max_row}"

    wb.save(out_path)
    return True


def write_csv(tables, out_path):
    base, _ = os.path.splitext(out_path)
    paths = []
    used = set()
    for idx, (title, rows) in enumerate(tables, 1):
        name = safe_sheet_name(title, used)
        path = f"{base}_{idx}_{name}.csv" if len(tables) > 1 else f"{base}.csv"
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f).writerows(rows)
        paths.append(path)
    return paths


def main():
    parser = argparse.ArgumentParser(description="Markdown case table -> Excel")
    parser.add_argument("input", help="Markdown case file")
    parser.add_argument("-o", "--output", default=None, help="Output xlsx path, defaults to same name as input")
    args = parser.parse_args()

    if not os.path.isfile(args.input):
        print(f"[ERROR] File not found: {args.input}", file=sys.stderr)
        return 1

    with open(args.input, encoding="utf-8") as f:
        tables = parse_markdown_tables(f.read())

    if not tables:
        print("[ERROR] No Markdown table found (need a | header | row and a |---| separator)", file=sys.stderr)
        return 1

    out_path = args.output or os.path.splitext(args.input)[0] + ".xlsx"

    if write_xlsx(tables, out_path):
        print(f"Generated: {out_path} ({len(tables)} sheet(s))")
        for title, rows in tables:
            print(f"  - {title}: {max(len(rows) - 1, 0)} rows")
        return 0

    csv_paths = write_csv(tables, out_path)
    print("[WARN] openpyxl not installed; degraded to CSV output:")
    for p in csv_paths:
        print(f"  - {p}")
    print("Re-run after install to get xlsx: pip install openpyxl")
    return 0


if __name__ == "__main__":
    sys.exit(main())
