# Test Plan — {project} {version}

| Item | Content |
|---|---|
| Version | {v1.2.0} |
| Plan written / updated | {date} |
| Test owner | {name} |
| Handoff date / test window | {date} ~ {date} |
| Related docs | Requirement {REQ-xxx}, Design {link}, API doc {link} |

## 1. Test objective and scope

**In scope**
- New features: {…}
- Changed features: {…}
- Related regression: {…}

**Out of scope** (and why)
- {…} — {reason}

## 2. Test strategy

| Test type | Scope | Method | Tool | Owner |
|---|---|---|---|---|
| Functional | {module} | Manual + cases | Case set | |
| API automation | {API list} | pytest parametrize | requests | |
| UI automation | {core flows} | Playwright | Playwright | |
| Regression | {P0/P1 case set} | CI gate | pytest -m smoke | |
| Compatibility | {browsers / devices} | Manual | | |
| Performance | {key APIs} | Load test | locust / jmeter | |
| Security | {escalation / injection} | Manual + scan | | |

## 3. Environment and data

| Env | Address | Version | Data prep | Notes |
|---|---|---|---|---|
| dev | | | | |
| test | | | | |
| staging | | | | |

- Test accounts and permission matrix: {…}
- Data-init script / data-build plan: {…}
- Third parties needing joint debug: {…} (incl. mock plan)

## 4. Schedule and milestones

| Stage | Time | Deliverable | Done when |
|---|---|---|---|
| Requirement review & testability challenge | | Issue list | No ambiguous requirement |
| Case design & review | | Case set | Review passed, coverage self-check done |
| Automation script dev | | Test code | Runs locally |
| Smoke test | | Smoke report | 100% smoke pass before system test |
| System test / regression | | Defect list | |
| Acceptance & release review | | Test report | Entry/exit criteria met |

## 5. Entry / exit criteria

**Entry (conditions to start system test)**
- [ ] Handoff ticket complete: change scope, impact, deploy method, self-test result
- [ ] Smoke cases 100% pass
- [ ] Test env deployed, API doc matches reality

**Exit (conditions to allow release)**
- [ ] Case execution rate 100%, pass rate ≥ {98}%
- [ ] S1/S2 defects cleared, S3 leftovers ≤ {3} with workaround and fix plan
- [ ] Regression cases all green (CI smoke passes)
- [ ] No blocking performance / security issue
- [ ] Release and rollback plan reviewed

## 6. Risks and responses

| Risk | Probability | Impact | Response | Owner |
|---|---|---|---|---|
| Dependency not ready | Medium | High | Mock early; agree a joint-debug window | |
| Test time compressed | Medium | High | Prioritize P0/P1; move P2/P3 to next round | |
| Legacy-data compat issue | Low | High | Build legacy-data dedicated verification | |

## 7. Deliverables checklist
- [ ] Test case set
- [ ] Automation code + run instructions
- [ ] Defect list
- [ ] Test report
