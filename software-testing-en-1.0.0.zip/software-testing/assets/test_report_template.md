# Test Report — {project} {version}

| Item | Content |
|---|---|
| Version / handoff batch | {v1.2.0 / 2nd handoff} |
| Test period | {start} ~ {end} |
| Tester | {name} |
| Test env | {test / staging} + version {commit} |
| Report date | {date} |

## 1. Conclusion

**Release recommendation: ✅ Ship / ⚠️ Ship with conditions / ❌ Do not ship**

One-line conclusion: {core features passed; 2 leftover S3 defects both have workarounds; recommend release on schedule.}

## 2. Execution

| Metric | Value |
|---|---|
| Planned / executed cases | n / n (execution rate n%) |
| Pass / fail / blocked | n / n / n (pass rate n%) |
| P0 case pass rate | n% |
| Automated cases / CI runs | n / daily build |
| Execution round | Round n |

By module:

| Module | Cases | Pass | Fail | Pass rate | Notes |
|---|---|---|---|---|---|
| | | | | | |

## 3. Defect stats and distribution

| Severity | New | Fixed | To fix | Leftover (deferred / wontfix) |
|---|---|---|---|---|
| S1 Critical | | | | |
| S2 Serious | | | | |
| S3 Normal | | | | |
| S4 Minor | | | | |
| Total | | | | |

Defect trend (by day): fixed vs new; converging is healthy.

**Top defects** (list unclosed S1/S2/S3)

| Defect ID | Title | Severity | Status | Impact | Workaround | Planned fix |
|---|---|---|---|---|---|---|
| BUG-001 | | S2 | Deferred | | | v1.2.1 |

## 4. Defect root-cause distribution

| Root-cause type | Count | Share | Improvement |
|---|---|---|---|
| Unclear req / design | | | Add testability challenge list to req review |
| Logic error | | | Add unit tests / case review |
| Inconsistent interface contract | | | Contract testing |
| Unhandled boundary | | | Unified param-validation interception |
| Env / config | | | Config checklist |

## 5. Dedicated test results

| Area | Conclusion | Key data |
|---|---|---|
| API automation | Pass | n cases, CI all green |
| Performance | Meet / miss | p95 = {xxx} ms, threshold {xxx} ms |
| Security | No high-risk | Escalation / injection verified |
| Compatibility | Pass | {browsers / devices} |
| Regression | Pass | No new regression |

## 6. Risks and leftovers

| Risk | Level | Notes | Response |
|---|---|---|---|
| | | | |

## 7. Improvement suggestions
1. {Actionable suggestion on process / tooling / case harvesting}
2. {Next-round test focus}

## 8. Attachments
- Case set: {link}
- Defect list: {link}
- CI report / Allure report: {link}
