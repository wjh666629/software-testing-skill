# Defect Report Template

## Single defect (Markdown)

```markdown
### BUG-{ID}｜[Module] condition + symptom

| Field | Content |
|---|---|
| Severity | S1 Critical / S2 Serious / S3 Normal / S4 Minor |
| Priority | P1 Immediate / P2 High / P3 Medium / P4 Low |
| Status | New |
| Environment | Version {commit}｜{test/staging}｜Chrome 126 / iOS 17 |
| Repro rate | Always / 1 of 3 |
| Reporter / Assignee | {name} / {dev} |
| Requirement / Case | REQ-1024 / TC-ORDER-007 |

**Preconditions**
1. Logged-in account test01 (normal-user permission)
2. Account holds an unexpired 10-yuan coupon

**Repro steps**
1. Open product detail, select product A (100 yuan)
2. Click "Buy now", go to order-confirm page
3. Select coupon "50 off 10"
4. Click "Submit order" and complete payment

**Actual result**
- Order paid 100 yuan, coupon not deducted
- API `POST /api/order/pay` response: `{"code":0,"data":{"payAmount":10000,"couponId":null}}`
- Screenshot: {link}

**Expected result**
- Pay amount should be 90 yuan; response `payAmount=9000, couponId=xxx`
- Coupon status set to USED, related order id correct

**Impact scope**
All users using the discount coupon; wrong amount is a money-loss issue, estimated 100% impact. No workaround.

**Extra clues (optional)**
Logs show coupon_service returned `COUPON_NOT_FOUND`, suspect product A not bound to a coupon template. Related log traceId: `abc123`.
```

## Defect list (summary table)

| Defect ID | Title | Module | Severity | Priority | Status | Repro rate | Reporter | Assignee | Planned fix |
|---|---|---|---|---|---|---|---|---|---|
| BUG-001 | [Order] Discount coupon not deducted at payment | Order | S1 | P1 | In Progress | Always | Zhang | Li | v1.2.0 |
| BUG-002 | [Login] Account not locked after repeated wrong passwords | Login | S2 | P2 | Fixed | Always | Zhang | Wang | v1.2.0 |
| BUG-003 | [List] Sort icon reversed from actual sort | List | S4 | P4 | Deferred | Always | Zhang | — | v1.3.0 |
