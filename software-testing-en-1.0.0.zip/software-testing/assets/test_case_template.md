# Test Case Set — {system under test}

> Version: {version}　|　Module: {module}　|　Author: {author}　|　Date: {date}
> Method tags: EP=Equivalence Partitioning, BVA=Boundary Value Analysis, DT=Decision Table, SC=Scenario, ST=State Transition, EG=Error Guessing

## 1. Case overview

| Metric | Count |
|---|---|
| Total cases | n |
| P0 (smoke) | n |
| P1 / P2 / P3 | n / n / n |
| Functional / Boundary / Exception / Security / Performance | n / n / n / n / n |

## 2. Test cases

| Case ID | Module | Title | Preconditions | Steps | Test data | Expected | Priority | Type | Method | Requirement |
|---|---|---|---|---|---|---|---|---|---|---|
| TC-LOGIN-001 | Login | Log in with correct account and password, redirect to home | Active account test01 | 1. Open login page<br>2. Enter account & password<br>3. Click login | user=test01<br>pwd=Test@123 | ① API code=0 and returns token<br>② Redirect to /home<br>③ DB last_login_time updated | P0 | Functional | SC | REQ-1024 |
| TC-LOGIN-002 | Login | Wrong password, prompt "wrong account or password" and no token returned | Same as above | 1. Enter correct account<br>2. Enter wrong password<br>3. Click login | pwd=wrong | ① HTTP 200, code=1001<br>② Response has no token<br>③ Stays on login page | P0 | Exception | EP | REQ-1024 |
| TC-LOGIN-003 | Login | 5 wrong passwords in a row locks account for 10 minutes | Account not locked | Repeat wrong login 5 times | pwd=wrong ×5 | ① 5th attempt prompts "account locked"<br>② DB status=LOCKED, lock_until=now+10min<br>③ Correct password also rejected during lock | P1 | Security | BVA | REQ-1025 |
| TC-LOGIN-004 | Login | Password length boundary: 1 / 7 / 8 / 20 / 21 chars | - | Submit each | len=1/7/8/20/21 | 8~20 chars pass validation; 1/7/21 blocked at frontend and API returns param-validation error | P2 | Boundary | BVA | REQ-1024 |
| TC-LOGIN-005 | Login | Username with special chars `<script>alert(1)</script>` not executed and correctly escaped | - | Submit that username | see data column | ① Page shows it literally, no popup<br>② API returns param-format error | P1 | Security | EG | REQ-1024 |

## 3. Coverage matrix

| Coverage dimension | Status | Notes |
|---|---|---|
| Valid / invalid equivalence | ✅ / ⚠️ | |
| Boundary values | ✅ / ⚠️ | |
| Decision-table rules / covered | n / n | |
| State transitions (valid / invalid) | n / n | |
| API error branches (401/403/404/500/timeout) | n / 5 | |
| Concurrency & idempotency | n | |
| Permission matrix | n | |

## 4. Automation suggestions

| Case ID | Automate? | Reason |
|---|---|---|
| TC-LOGIN-001 | Yes | P0 smoke, stable, enters CI gate |
| TC-LOGIN-005 | Yes | Security regression, low cost |
| Visual / UX | No | Manual is more cost-effective |

## 5. Uncovered items and risks

- {Uncovered feature} — Reason: {dependency not ready / env limit / time shortage}, risk level: {high/medium/low}
