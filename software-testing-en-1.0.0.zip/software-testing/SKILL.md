---
name: software-testing
description: End-to-end software testing engineering — testability review, test plan and strategy, test case design (equivalence partitioning, boundary value analysis, decision table, scenario, state transition, error guessing), pytest automation scaffolding, defect reports, and test summary reports. Use when the user mentions software testing, test cases, test plan, test strategy, automation, pytest, API testing, UI testing, Playwright, bug report, defect, regression, smoke test, coverage, or test report, or asks to design a test plan for a feature/module/API/web page, find bugs, or assess quality risk. Default stack is Python + pytest.
description_zh: 软件测试全流程：可测试性评估、测试计划、用例设计、pytest 自动化、缺陷报告、测试报告。
version: 1.0.0
license: MIT
---

# Software Testing — End-to-End

## Overview

Turn software testing from "scribble a few cases off the top of your head" into a repeatable engineering process: confirm requirements are testable, plan strategy and scope, design cases by method, codify stable cases into runnable pytest automation, then emit standardized defects and a summary report after execution.

Core principle: **Clarify requirement boundaries before you start. Guarantee coverage with methods, not inspiration. Every case must be decidable and reproducible. Automate whatever can be automated.**

## Trigger Routing

Decide which segment the user needs, then load the corresponding resources. Do not do everything at once:

| User intent | Workflow | Required reading |
|---|---|---|
| "Test X for me" / "See if this code has problems" | W1 + W3 + W5 | `references/checklists.md`, `references/test-design-techniques.md` |
| "Test this web page / HTML / frontend project" | W1 + W3 + W5, using Node + jsdom | `references/frontend-testing.md`, `references/checklists.md` |
| "Write a test plan / test strategy" | W2 | `assets/test_plan_template.md`, `references/checklists.md` |
| "Design test cases" / "Write cases" | W3 | `references/test-design-techniques.md`, `assets/test_case_template.md` |
| "Write automation code" / "pytest scripts" | W4 | `references/pytest-guide.md`, `scripts/scaffold_pytest.py` |
| "How do I file this bug" / "Write a defect report" | W5 | `references/defect-and-severity.md`, `assets/defect_report_template.md` |
| "Produce a test report" / "Summarize the results" | W6 | `assets/test_report_template.md`, `references/defect-and-severity.md` |
| Full-version testing (release handoff) | W1→W2→W3→W4→W5→W6 in order | All |

## Ground Rules

1. **Clarify boundaries before designing.** When requirement or API docs are missing or ambiguous, first use the *testability challenge checklist* (`references/checklists.md`, Section 9) to list open questions, state your own reasonable assumptions and mark them. Do not stall waiting for confirmation.
2. **One case verifies one point.** The expected result must be decidable (specific status code, field value, DB row) — never phrasing like "displays normally".
3. **Cases are independent.** They must not depend on execution order; build test data with fixtures and clean up afterward.
4. **Coverage over count.** Self-check against the coverage matrix and fill gaps; do not pile up duplicate cases.
5. **Never fake execution results.** When you cannot actually run the tests (no environment, no dependencies), state explicitly "NOT EXECUTED" — do not fabricate a pass rate.
6. **All output lands in files.** Do not dump large tables only in the chat; see "Output Conventions" for file names.
7. **Degrade when the stack mismatches.** When the system under test has no Python entry point (static frontend, Node project), do not force pytest — switch to Node + jsdom (`references/frontend-testing.md`). Any assertion that depends on layout or real rendering (scroll highlight, visibility, responsiveness) cannot be validated by jsdom; mark it "NOT EXECUTED" and route to manual testing or Playwright.

## W1 Requirement / Code Testability Assessment

1. Read the requirement doc, API doc, or source code; map out: features, input parameters, business rules, state machine, data flow, dependencies.
2. Walk `references/checklists.md` Section 9 *testability challenge checklist* line by line; produce an **open-questions list** (with affected test points).
3. Identify risk areas: money / inventory / concurrency / permissions / async callbacks / legacy-data compatibility — flag as high risk.
4. Output: feature list + open questions + risk areas + recommended test depth.

## W2 Test Plan and Strategy

1. Copy `assets/test_plan_template.md` to the target dir and fill by field.
2. Define **in scope / out of scope** and the regression scope (impact analysis of the change).
3. Set strategy: what is manual, what is automated, what enters the CI smoke gate.
4. Pin entry / exit criteria (smoke 100% pass before system testing; S1/S2 cleared before release).
5. List environments, accounts, data setup, third-party mock plan, and risk responses.

## W3 Test Case Design

1. Pick a design method by feature (`references/test-design-techniques.md`):
   - Input with range → equivalence partitioning + boundary value analysis
   - Multi-condition combinations → decision table (use pairwise for combinatorial explosion)
   - End-to-end flow → scenario (basic + alternative + exceptional flow)
   - Has a state machine → state transition (valid + invalid transitions)
   - Mop-up → error guessing (weak network, concurrency, time zones, emoji, money precision, double clicks)
2. Produce using the `assets/test_case_template.md` table structure, with all fields filled (ID / module / title / preconditions / steps / data / expected / priority / type / method / requirement).
3. Case ID format `TC-<MODULE>-<NNN>`; priority P0~P3 per the definitions.
4. Self-check with the **coverage matrix**: param pos/neg/boundary, API error branches (401/403/404/500/timeout), idempotency & concurrency, permission matrix, list empty/single/full/over-page. Fill whatever is missing.
5. If the user wants Excel on delivery, run `scripts/cases_to_xlsx.py`:

```bash
python scripts/cases_to_xlsx.py cases.md -o cases.xlsx
```

Each Markdown table becomes one sheet; the sheet name comes from the nearest heading. If `openpyxl` is not installed, it automatically degrades to CSV.

## W4 Automation Scripts

Default is pytest (`references/pytest-guide.md`); for pure-frontend static pages, switch to Node + jsdom (`references/frontend-testing.md`).

1. When first scaffolding a test project, run the scaffold, then edit on top of it:

```bash
python scripts/scaffold_pytest.py --dir ./autotest --type api   # api | ui | both
```

Generates `pytest.ini`, `conftest.py` (auth fixture), `utils/client.py`, `utils/assert_util.py`, example cases, and a README. Existing files are not overwritten by default; add `--force` to overwrite.

2. Follow `references/pytest-guide.md` strictly: directory layout, layered fixtures, parametrized data-driven tests, layered assertions (HTTP → business code → structure → DB), the seven API dimensions that must be tested, and `expect()` auto-wait for UI.
3. Coverage strategy: P0 and stable regression cases get the `smoke` marker and enter CI; experience-grade or one-off checks stay manual.
4. Environment config goes through env vars; never hardcode domain, account, or keys.
5. After writing, do static validation: `pytest --collect-only -q` to confirm collection; if the environment is complete, actually run and report results, otherwise state clearly that it was not run and why.

## W5 Defect Reports

1. Decide severity & priority (S1~S4 / P1~P4, see `references/defect-and-severity.md`) and write one sentence of reasoning.
2. Fill `assets/defect_report_template.md`, focusing on the **minimal reproduction path** and **complete evidence** (response body, logs, screenshot, traceId).
3. One defect per report; intermittent defects must state frequency and trigger conditions.
4. Before submitting, self-check against the "common rejection reasons" list.
5. If the user gave source code, add initial root-cause hints (module / line / config) when you can; mark it as a guess when unsure.

## W6 Test Report

1. Copy `assets/test_report_template.md`, fill execution data (execution rate / pass rate / P0 pass rate), defect grading stats and trends, and dedicated conclusions (perf p95, security, compatibility, regression).
2. Do root-cause distribution analysis and give **actionable improvement suggestions** (process, tooling, case harvesting), not just a list of numbers.
3. Give a clear release recommendation: ship / ship with conditions (list them) / do not ship — aligned with W2 exit criteria.
4. Residual defects must carry impact, workaround, and planned fix version.

## Output Conventions

| Deliverable | Suggested path | Template |
|---|---|---|
| Test plan | `docs/test-plan-<version>.md` | `assets/test_plan_template.md` |
| Case set | `docs/test-cases-<module>.md` (convertible to `.xlsx`) | `assets/test_case_template.md` |
| Automation code | `autotest/` project dir | `scripts/scaffold_pytest.py` |
| Defect report | `docs/bugs-<version>.md` | `assets/defect_report_template.md` |
| Test report | `docs/test-report-<version>.md` | `assets/test_report_template.md` |

After producing output, use `present_files` to show the files and give key conclusions in your reply (case count, coverage gaps, risk items, release recommendation) — do not just say "generated".

## Resource Index

### scripts/
- `scaffold_pytest.py` — scaffold a pytest project (api/ui/both), with conftest, client, assertion utils, example cases
- `cases_to_xlsx.py` — convert Markdown case tables to Excel (multi-table multi-sheet; degrades to CSV when openpyxl is absent)

### references/
- `test-design-techniques.md` — seven case-design methods, field spec, priority definitions, coverage matrix
- `pytest-guide.md` — layout, fixtures, parametrization, assertions, API/UI practice, run commands, flaky governance, multi-language mapping
- `frontend-testing.md` — Node + jsdom path when there is no Python entry; scaffold, eval scope pitfalls, animation waits, frontend focus points
- `defect-and-severity.md` — defect grading & priority, status flow, report essentials, RCA categories, rejection self-check
- `checklists.md` — nine categories of test-point checklists (functional / boundary-exception / concurrency-idempotency / permission-security / data-consistency / compatibility / performance / observability / requirement challenges)

### assets/
- `test_case_template.md`, `test_plan_template.md`, `test_report_template.md`, `defect_report_template.md` — four deliverable templates, with filled examples

### examples/
- `biomed-frontend-case/` — a real, complete test case (35 cases / 12 defects), with `node`-runnable test scripts; reference this when a pure-frontend project goes the Node+jsdom path

### Package docs
- `README.md` — user guide (capabilities, trigger words, install, case study)
- `SECURITY.md` — security self-check conclusions for the two scripts (no network, no credentials, no code execution)
- `CHANGELOG.md` — version history and known limitations
