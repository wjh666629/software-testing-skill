#!/usr/bin/env python3
"""初始化一个 pytest 自动化测试工程骨架。

用法:
    python scaffold_pytest.py --dir ./autotest --type api
    python scaffold_pytest.py --dir ./autotest --type both --force

参数:
    --dir   目标目录，默认当前目录下的 autotest
    --type  api | ui | both，默认 both
    --force 已存在的文件也覆盖（默认跳过，避免破坏已有内容）
"""
import argparse
import os
import sys

PYTEST_INI = """[pytest]
testpaths = tests
addopts = -v --strict-markers --tb=short
markers =
    smoke: 冒烟用例 P0
    regression: 回归用例
    api: 接口测试
    ui: UI 测试
    slow: 执行较慢的用例
    flaky: 不稳定用例，允许重试
"""

REQUIREMENTS_API = """pytest>=7.4
requests>=2.31
PyYAML>=6.0
jsonschema>=4.20
pytest-html>=4.1
pytest-xdist>=3.5
pytest-rerunfailures>=12.0
allure-pytest>=2.13
"""

REQUIREMENTS_UI = """playwright>=1.44
pytest-playwright>=0.4
"""

CONFTEST = '''"""全局 fixture：配置、鉴权、HTTP 客户端。

环境变量（见 .env.example）：BASE_URL / TEST_USER / TEST_PWD
"""
import os

import pytest
import requests


@pytest.fixture(scope="session")
def base_url():
    return os.getenv("BASE_URL", "http://localhost:8080")


@pytest.fixture(scope="session")
def token(base_url):
    """登录获取 token，整个 session 复用。"""
    resp = requests.post(
        f"{base_url}/api/login",
        json={
            "username": os.getenv("TEST_USER", ""),
            "password": os.getenv("TEST_PWD", ""),
        },
        timeout=10,
    )
    assert resp.status_code == 200, f"登录失败: {resp.status_code} {resp.text}"
    return resp.json()["data"]["token"]


@pytest.fixture()
def api(base_url, token):
    """带鉴权的 HTTP 会话。"""
    session = requests.Session()
    session.headers.update(
        {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    )
    session.base_url = base_url
    yield session
    session.close()
'''

CLIENT = '''"""HTTP 客户端封装：统一超时、日志、错误处理。"""
from typing import Any, Optional

import requests


class ApiClient:
    def __init__(self, base_url: str, token: str = "", timeout: int = 10):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"

    def request(self, method: str, path: str, **kwargs) -> requests.Response:
        url = path if path.startswith("http") else f"{self.base_url}{path}"
        kwargs.setdefault("timeout", self.timeout)
        resp = self.session.request(method, url, **kwargs)
        # 失败时把上下文打进日志，便于定位
        if resp.status_code >= 500:
            print(f"[ERROR] {method} {url} -> {resp.status_code}: {resp.text[:500]}")
        return resp

    def get(self, path: str, params: Optional[dict] = None, **kwargs):
        return self.request("GET", path, params=params, **kwargs)

    def post(self, path: str, json: Any = None, **kwargs):
        return self.request("POST", path, json=json, **kwargs)

    def put(self, path: str, json: Any = None, **kwargs):
        return self.request("PUT", path, json=json, **kwargs)

    def delete(self, path: str, **kwargs):
        return self.request("DELETE", path, **kwargs)
'''

ASSERT_UTIL = '''"""通用断言工具：分层断言，失败信息可读。"""
from typing import Any, Iterable


def assert_http_ok(resp, timeout_msg: str = "") -> dict:
    """HTTP 200 + 业务码 0，返回 data。"""
    assert resp.status_code == 200, (
        f"HTTP {resp.status_code}, 期望 200。响应: {resp.text[:500]} {timeout_msg}"
    )
    body = resp.json()
    assert body.get("code") == 0, f"业务码 {body.get('code')}, 期望 0。响应: {body}"
    return body.get("data") or {}


def assert_keys(obj: dict, required: Iterable[str], optional: Iterable[str] = ()):
    """校验响应字段完整性，字段缺失比字段错误更常见。"""
    missing = [k for k in required if k not in obj]
    assert not missing, f"缺少必填字段: {missing}，实际字段: {list(obj)}"


def assert_pagination(data: dict, expected_page_size: int = 20):
    assert "total" in data and "list" in data, f"分页结构异常: {list(data)}"
    assert len(data["list"]) <= expected_page_size, "单页条数超过页大小"


def assert_db_equal(actual: Any, expected: Any, field: str = ""):
    assert actual == expected, f"DB 字段 {field} 期望 {expected}, 实际 {actual}"
'''

TEST_API = '''"""接口测试示例：覆盖 成功 / 参数错误 / 越权 / 不存在 / 幂等。"""
import pytest

from utils.assert_util import assert_http_ok, assert_keys

pytestmark = [pytest.mark.api]


@pytest.mark.smoke
def test_query_user_success(api):
    resp = api.get("/api/user/1")
    data = assert_http_ok(resp)
    assert_keys(data, ["id", "username", "status"])


@pytest.mark.parametrize("user_id,expected_code", [
    (1, 0),        # 有效等价类
    (0, 404),      # 边界：0
    (-1, 404),     # 边界：负数
    ("abc", 400),  # 类型错误
])
def test_query_user_invalid_param(api, user_id, expected_code):
    resp = api.get(f"/api/user/{user_id}")
    assert resp.json()["code"] == expected_code, resp.text


def test_query_user_without_token(base_url):
    """无鉴权访问应被拒绝。"""
    import requests
    resp = requests.get(f"{base_url}/api/user/1", timeout=10)
    assert resp.status_code in (401, 403), f"未鉴权却可访问: {resp.status_code}"


def test_create_order_idempotent(api):
    """重复提交同一请求，只应产生一条记录。"""
    payload = {"skuId": 1001, "quantity": 1, "requestId": "req-test-001"}
    r1 = api.post("/api/order", json=payload)
    r2 = api.post("/api/order", json=payload)
    assert_http_ok(r1)
    assert_http_ok(r2)
    assert r1.json()["data"]["orderId"] == r2.json()["data"]["orderId"], "幂等失效"
'''

TEST_UI = '''"""UI 测试示例（Playwright）。"""
import pytest
from playwright.sync_api import expect

pytestmark = [pytest.mark.ui]


@pytest.mark.smoke
def test_login_success(page, base_url):
    page.goto(f"{base_url}/login")
    page.get_by_label("用户名").fill("test01")
    page.get_by_label("密码").fill("Test@123")
    page.get_by_role("button", name="登录").click()
    expect(page).to_have_url(f"{base_url}/home")


def test_login_with_wrong_password(page, base_url):
    page.goto(f"{base_url}/login")
    page.get_by_label("用户名").fill("test01")
    page.get_by_label("密码").fill("wrong_pwd")
    page.get_by_role("button", name="登录").click()
    expect(page.get_by_text("账号或密码错误")).to_be_visible()
'''

DATA_YAML = """# 数据驱动用例数据示例
# 用 yaml.safe_load 读取后传给 pytest.mark.parametrize
create_order_amount:
  - [0, 400]        # 边界：0
  - [1, 0]          # 有效
  - [999999, 0]     # 有效
  - [-1, 400]       # 无效：负数
  - ["abc", 400]    # 无效：类型错误
"""

ENV_EXAMPLE = """BASE_URL=http://localhost:8080
TEST_USER=test01
TEST_PWD=Test@123
"""

README = """# 自动化测试工程

## 安装

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
{ui_install}cp .env.example .env   # 填入真实配置
```

## 运行

```bash
pytest -m smoke                    # 只跑冒烟(P0)
pytest -m "api and not slow" -n 4  # 接口用例 4 进程并发
pytest --reruns 2 -m flaky         # 不稳定用例重试
pytest --html=report.html --self-contained-html
pytest --alluredir=allure-results && allure serve allure-results
```

## 目录说明

- `conftest.py` 全局 fixture（配置、鉴权、客户端）
- `tests/api/` 接口用例，`tests/ui/` UI 用例
- `utils/` 客户端封装、通用断言、DB 校验
- `data/` 数据驱动用例数据（yaml/json）

## 纪律

1. 用例之间不共享可变状态，数据用 fixture 造并在 teardown 清理
2. 断言具体到字段，失败信息带上实际响应
3. 禁止 time.sleep 硬等待，UI 用 expect 自动等待
4. 新增用例必须打 marker，P0 打 smoke
"""


def write(path: str, content: str, force: bool) -> bool:
    """写入文件；已存在且非 force 时跳过。返回是否写入。"""
    if os.path.exists(path) and not force:
        return False
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return True


def main():
    parser = argparse.ArgumentParser(description="初始化 pytest 自动化测试工程骨架")
    parser.add_argument("--dir", default="autotest", help="目标目录，默认 ./autotest")
    parser.add_argument("--type", choices=["api", "ui", "both"], default="both",
                        help="工程类型：接口 / UI / 两者")
    parser.add_argument("--force", action="store_true", help="覆盖已存在文件")
    args = parser.parse_args()

    root = os.path.abspath(args.dir)
    need_api = args.type in ("api", "both")
    need_ui = args.type in ("ui", "both")

    files = {
        os.path.join(root, "pytest.ini"): PYTEST_INI,
        os.path.join(root, "requirements.txt"):
            REQUIREMENTS_API + (REQUIREMENTS_UI if need_ui else ""),
        os.path.join(root, "conftest.py"): CONFTEST,
        os.path.join(root, ".env.example"): ENV_EXAMPLE,
        os.path.join(root, "utils", "client.py"): CLIENT,
        os.path.join(root, "utils", "assert_util.py"): ASSERT_UTIL,
        os.path.join(root, "data", "cases_example.yaml"): DATA_YAML,
        os.path.join(root, "README.md"): README.format(
            ui_install=("playwright install\n" if need_ui else "")
        ),
    }
    if need_api:
        files[os.path.join(root, "tests", "api", "test_example_api.py")] = TEST_API
    if need_ui:
        files[os.path.join(root, "tests", "ui", "test_example_ui.py")] = TEST_UI

    # 包内 __init__ 非必需，pytest 用 rootdir 导入；保留 utils 可 import
    files[os.path.join(root, "utils", "__init__.py")] = ""

    created, skipped = [], []
    for path, content in files.items():
        (created if write(path, content, args.force) else skipped).append(path)

    print(f"工程已生成: {root}")
    print(f"新建 {len(created)} 个文件" + (f"，跳过 {len(skipped)} 个已存在文件" if skipped else ""))
    for p in sorted(created):
        print(f"  + {os.path.relpath(p, root)}")
    print("\n下一步:")
    print(f"  cd {root}")
    print("  pip install -r requirements.txt")
    print("  cp .env.example .env && 修改 .env")
    print("  pytest -m smoke")
    return 0


if __name__ == "__main__":
    sys.exit(main())
