# 前端静态页面测试路径（无 Python 后端时的降级方案）

当被测对象是纯前端项目（静态 HTML + JS，无后端接口、无 Python 环境）时，不要用 pytest 硬套。
改用 **Node 内置断言 + jsdom** 驱动页面逻辑，秒级执行、不依赖浏览器与网络。
有浏览器条件时再升级到 Playwright 做真实渲染验证。

## 一、选型判断

| 场景 | 方案 |
|---|---|
| 纯静态页 / 前端组件逻辑 | Node + jsdom（本文件方案） |
| 需要真实渲染、布局、视觉回归 | Playwright + 真实浏览器 |
| 有后端接口 | 回到 pytest + requests（`references/pytest-guide.md`） |

## 二、环境

```bash
npm install jsdom          # 装到隔离工作区，勿全局
NODE_PATH=<workspace>/node_modules node tests/dom.test.js
```

## 三、脚手架模板

```js
const fs = require('fs'), path = require('path');
const { JSDOM } = require('jsdom');
const SRC = process.env.SRC_DIR || '<被测目录>';

const dom = new JSDOM(fs.readFileSync(path.join(SRC, 'index.html'), 'utf8'),
  { runScripts: 'dangerously', pretendToBeVisual: true });
const win = dom.window, doc = win.document;

// 1) canvas 打桩（jsdom 不实现 getContext）
win.HTMLCanvasElement.prototype.getContext = () => ({
  canvas: { width: 600, height: 400 }, clearRect(){}, save(){}, restore(){},
  beginPath(){}, measureText: () => ({ width: 10 }),
});

// 2) 图表库打桩：记录实例与 update 次数，用于断言"图表是否刷新"
win.__chartInstances = [];
win.Chart = function (ctx, config) {
  this.data = config.data; this.options = config.options; this.type = config.type;
  this.updateCount = 0;
  this.update = function () { this.updateCount++; };
  win.__chartInstances.push(this);
};

// 3) jsdom 不实现 scrollIntoView
win.Element.prototype.scrollIntoView = function () { win.__lastScrolled = this; };

// 4) 关键：eval 里的 const/let 是 eval 私有作用域，不会挂到 window。
//    必须在同一段 eval 末尾显式导出，否则脚本之间互相看不见，报 xxx is not defined。
function loadScript(file, exports) {
  const code = fs.readFileSync(path.join(SRC, file), 'utf8');
  win.eval(code + exports.map(n => `;window.${n} = ${n};`).join(''));
}
loadScript('data.js', ['medicalData']);
loadScript('app.js', ['charts', 'currentFilters']);
doc.dispatchEvent(new win.Event('DOMContentLoaded'));  // 手动触发，jsdom 已错过该时机

const E = expr => win.eval(expr);   // 读取脚本内部变量
```

## 四、三个必踩的坑

1. **`const`/`let` 不挂 window**（见上 `loadScript`）。`function` 声明会挂上去，`const` 不会。
2. **动画是异步的**：数字滚动/进度条类断言前必须 `await sleep(步数 × 间隔 + 余量)`，否则读到初始值。
   jsdom 里 `setInterval` 真的会跑，需要 `pretendToBeVisual: true`。
3. **jsdom 无布局引擎**：`offsetTop`、`getBoundingClientRect`、CSS `display` 计算全部返回 0，
   凡是依赖布局的断言（滚动高亮、元素可见性、响应式）jsdom 验证不了，**必须标注"未实际执行"**并转人工/Playwright。

## 五、纯数据层的快速验证（零依赖）

若被测 JS 是纯数据模块（无 DOM 依赖），连 jsdom 都不用装：

```js
const vm = require('vm');
const ctx = vm.createContext({ console });
vm.runInContext(fs.readFileSync('data.js', 'utf8'), ctx);
const md = vm.runInContext('medicalData', ctx);   // 直接取值断言
```

## 六、前端重点测什么

- 数据血缘：图表里的每个维度，在源数据里都能找到对应字段（缺字段却被"造"出来是最严重的一类缺陷）
- 联动一致性：筛选变更后，**所有**图表是否都刷新（常见遗漏某个 update 调用）
- 静默截断：`slice(0, N)` 之类的采样是否有提示
- 写死指标：页面上的统计数字是算出来的还是 HTML 硬编码
- 键盘可达性：`<li onclick>` 这类裸元素无法 Tab 聚焦
- 依赖可用性：CDN 外链是否有本地兜底
- id 唯一性：重复 id 会让锚点/JS 选择器命中错误元素

## 七、断言输出规范

打印 `PASS/FAIL + 用例ID + 名称`，失败信息里带上**实际值**（"实际 14，期望 30"），
末尾汇总通过/失败数，`process.exit(fail ? 1 : 0)` 以便接 CI。
