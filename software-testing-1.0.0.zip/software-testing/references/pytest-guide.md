# pytest 工程规范与代码模板

默认技术栈：Python + pytest。接口测试用 `requests`，UI 测试用 `playwright`，报告用 `allure-pytest` 或 `pytest-html`。
若被测项目是 Java/JS 技术栈，保留本文件的**结构与策略**，把语法换成 JUnit5/TestNG 或 Playwright/Jest（见文末对照表）。

## 一、推荐目录结构

```
tests/
├── conftest.py              # 全局 fixture：配置、鉴权、客户端、数据清理
├── pytest.ini               # 或 pyproject.toml 中的 [tool.pytest.ini_options]
├── requirements.txt
├── api/                     # 接口层：一个业务域一个文件
│   ├── test_login.py
│   └── test_order.py
├── ui/                      # UI 层（Playwright）
│   └── test_checkout.py
├── data/                    # 测试数据（yaml/json/csv）
│   └── cases_order.yaml
└── utils/
    ├── client.py            # 封装 requests：base_url、超时、重试、日志、鉴权头
    ├── assert_util.py       # 通用断言：状态码、JSON schema、DB 校验
    └── db.py                # 数据库连接与断言
```

命名约定：文件 `test_*.py`，类 `Test*`，函数 `test_*`；非测试辅助函数不要以 `test` 开头。

## 二、pytest.ini 推荐配置

```ini
[pytest]
testpaths = tests
addopts = -v --strict-markers --tb=short
markers =
    smoke: 冒烟用例，P0
    regression: 回归用例
    api: 接口测试
    ui: UI 测试
    slow: 执行较慢的用例
    flaky: 不稳定用例，需重试
```

常用插件：`pytest-xdist`（并发）、`pytest-rerunfailures`（失败重试）、`pytest-order`（顺序）、`pytest-mock`（mock）、`pytest-html` / `allure-pytest`（报告）、`pytest-cov`（覆盖率）。

## 三、Fixture 组织原则

- 按作用域分层：`session`（登录态、全局配置）> `module` > `function`（每条用例独立数据）
- 测试数据用 fixture **生成并在 teardown 中清理**，保证用例可重复执行
- 环境配置从环境变量读取，禁止硬编码域名/账号/密钥

```python
# conftest.py 示例
import os, pytest, requests

@pytest.fixture(scope="session")
def base_url():
    return os.getenv("BASE_URL", "http://localhost:8080")

@pytest.fixture(scope="session")
def token(base_url):
    r = requests.post(f"{base_url}/api/login",
                      json={"username": os.getenv("TEST_USER"),
                            "password": os.getenv("TEST_PWD")},
                      timeout=10)
    assert r.status_code == 200, r.text
    return r.json()["data"]["token"]

@pytest.fixture()
def api(base_url, token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}",
                      "Content-Type": "application/json"})
    s.base_url = base_url
    yield s
    s.close()
```

## 四、参数化与数据驱动

```python
import pytest

@pytest.mark.api
@pytest.mark.parametrize("amount,expected_code", [
    (0, 0), (1, 0), (999999, 0),        # 边界内
    (-1, 400), (0.001, 400), ("abc", 400), (None, 400),  # 无效等价类
])
def test_create_order_amount(api, amount, expected_code):
    r = api.post("/api/order", json={"amount": amount}, timeout=10)
    assert r.status_code == 200
    assert r.json()["code"] == expected_code
```

数据量大时把用例数据放 `data/*.yaml`，用 `pytest.mark.parametrize` 加载；用例标题用 `ids=` 提高可读性。

## 五、断言写法

- 断言要**具体到字段**：`assert body["data"]["status"] == "PAID"` 而不是 `assert body`
- 先断言状态码，再断言业务码，再断言数据结构，最后断言数据库
- 失败信息可读：`assert r.json()["code"] == 0, f"期望0，实际{r.text}"`
- 结构校验用 `jsonschema`；字段缺失比字段错误更常见，务必校验必填字段存在

```python
def assert_ok(resp, timeout=10):
    assert resp.status_code == 200, f"HTTP {resp.status_code}: {resp.text}"
    body = resp.json()
    assert body.get("code") == 0, f"业务码异常: {body}"
    return body["data"]
```

## 六、接口测试必测维度（每个接口）

1. 成功响应（字段完整性、类型、排序、分页）
2. 参数校验：必填缺失、类型错误、超长、越界、特殊字符、SQL/XSS 注入串
3. 鉴权：无 token、过期 token、越权（他人资源）
4. 异常：资源不存在、依赖服务超时、服务返回 5xx
5. 幂等：重复提交相同请求（写接口）
6. 并发：同一资源并发写（锁/版本号/乐观锁）
7. 数据一致性：落库字段、关联表、缓存、消息是否一致

## 七、UI 测试要点（Playwright）

```python
from playwright.sync_api import expect

def test_login_success(page, base_url):
    page.goto(f"{base_url}/login")
    page.get_by_label("用户名").fill("test01")
    page.get_by_label("密码").fill("Test@123")
    page.get_by_role("button", name="登录").click()
    expect(page).to_have_url(f"{base_url}/home")
```

- 优先用 `get_by_role` / `get_by_label` 等语义化定位器，少用 XPath
- 用 `expect()` 自动等待，禁止 `time.sleep` 硬等待
- 一条 UI 用例只验证一条业务路径，登录态用 `storage_state` 复用

## 八、执行与报告

```bash
pip install -r requirements.txt
pytest -m smoke                       # 只跑冒烟
pytest -m "not slow" -n 4             # 4 进程并发
pytest --reruns 2 --reruns-delay 1    # 失败重试（仅对 flaky）
pytest --html=report.html --self-contained-html
pytest --alluredir=allure-results && allure serve allure-results
pytest --cov=src --cov-report=term-missing
```

CI 集成：GitHub Actions / GitLab CI 中 `pytest -m smoke` 作为门禁，P0 全绿才允许合并。

## 九、稳定性纪律（避免 flaky）

- 用例之间不共享可变状态；共享数据用深拷贝
- 外部依赖用 mock 或契约测试隔离；真实第三方只保留少量 e2e
- 时间相关：注入可控时钟，不要依赖 `datetime.now()`
- 异步结果：轮询等待 + 超时，而不是固定 sleep
- 失败重试只用于已知不稳定用例，并打 `flaky` 标记跟踪

## 十、其他技术栈对照

| 能力 | Python | Java | JS/TS |
|---|---|---|---|
| 测试框架 | pytest | JUnit5 / TestNG | Jest / Vitest / Playwright Test |
| 参数化 | `@pytest.mark.parametrize` | `@ParameterizedTest` | `test.each` |
| 前置后置 | fixture | `@BeforeEach` / `@AfterEach` | `beforeEach` / `afterEach` |
| HTTP | requests / httpx | RestAssured | axios / fetch / supertest |
| UI | Playwright(python) | Selenium / Playwright(java) | Playwright |
| Mock | pytest-mock / responses | Mockito | jest.mock / msw |
| 报告 | allure-pytest / pytest-html | allure-junit5 / surefire | allure-playwright |
