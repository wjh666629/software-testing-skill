/**
 * 生物医疗大数据分析平台 —— 数据层测试
 * 运行：node tests/data.test.js
 * 零依赖，直接用 vm 加载被测的 data.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const SRC = process.env.SRC_DIR
  || 'C:/Users/wjh/Desktop/it文化节/人工智能学院+计算机242+吴杰涵+大数据可视化设计';
const NODE = path.posix || {};

// 加载被测脚本
const code = fs.readFileSync(path.join(SRC, 'data.js'), 'utf8');
const ctx = vm.createContext({ console });
vm.runInContext(code, ctx);
const md = vm.runInContext('medicalData', ctx);

let pass = 0, fail = 0;
const failures = [];

function check(id, name, fn) {
  try {
    const detail = fn();
    pass++;
    console.log(`PASS  ${id}  ${name}${detail ? '  → ' + detail : ''}`);
  } catch (e) {
    fail++;
    failures.push({ id, name, msg: e.message });
    console.log(`FAIL  ${id}  ${name}\n        ${e.message}`);
  }
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }

console.log('=== 数据层测试 ===\n');

// ---------- 基础统计 ----------
check('TC-D-01', '患者总数为 303', () => {
  const total = md.patients.length;
  assert(total === 303, `期望 303，实际 ${total}`);
  return `${total} 条`;
});

check('TC-D-02', '疾病分布求和 == 患者总数', () => {
  const dist = md.getDiseaseDistribution();
  const sum = Object.values(dist).reduce((a, b) => a + b, 0);
  assert(sum === md.patients.length, `分布合计 ${sum} != 总数 ${md.patients.length}`);
  return JSON.stringify(dist);
});

check('TC-D-03', '性别分布求和 == 患者总数', () => {
  const g = md.getGenderDistribution();
  assert(g.male + g.female === md.patients.length,
    `男 ${g.male} + 女 ${g.female} != ${md.patients.length}`);
  return `男 ${g.male} / 女 ${g.female}`;
});

check('TC-D-04', '年龄分布求和 == 患者总数', () => {
  const a = md.getAgeDistribution();
  const sum = Object.values(a).reduce((x, y) => x + y, 0);
  assert(sum === md.patients.length, `年龄分组合计 ${sum} != ${md.patients.length}`);
  return JSON.stringify(a);
});

check('TC-D-05', 'getStats 字段完整且类型正确', () => {
  const s = md.getStats();
  ['totalPatients', 'avgAge', 'diseaseTypes', 'recoveryRate'].forEach(k =>
    assert(k in s, `缺少字段 ${k}`));
  assert(Number.isFinite(s.avgAge), `avgAge 非数字: ${s.avgAge}`);
  return JSON.stringify(s);
});

check('TC-D-06', 'recoveryRate 格式带百分号且数值合理', () => {
  const s = md.getStats();
  assert(typeof s.recoveryRate === 'string' && /^\d+%$/.test(s.recoveryRate),
    `recoveryRate 格式异常: ${s.recoveryRate}`);
  return s.recoveryRate;
});

// ---------- 语义正确性（预期暴露缺陷） ----------
check('TC-D-07', 'UI 标签“康复率”在数据中能找到对应依据', () => {
  const s = md.getStats();
  const hasRecoveryField = md.patients.some(p =>
    ['recovered', 'recovery', 'outcome'].some(k => k in p));
  assert(hasRecoveryField,
    `数据集中不存在“康复/转归”字段；“康复率 ${s.recoveryRate}”实为 target=0（未患病）占比 ${Math.round(md.patients.filter(p => p.target === 0).length / md.patients.length * 100)}%，标签与数据语义不符`);
  return s.recoveryRate;
});

// ---------- 月度趋势（预期暴露缺陷） ----------
check('TC-D-08', 'getMonthlyTrends 返回 12 个月且顺序正确', () => {
  const t = md.getMonthlyTrends();
  assert(t.length === 12, `期望 12 个月，实际 ${t.length}`);
  assert(t[0].month === '1月' && t[11].month === '12月',
    `月份顺序异常: ${t[0].month} ~ ${t[11].month}`);
  return t.map(x => x.month).join(',');
});

check('TC-D-09', '月度趋势数据可追溯到患者记录中的时间字段', () => {
  const hasTimeField = md.patients.some(p =>
    ['date', 'month', 'visitDate', 'time'].some(k => k in p));
  assert(hasTimeField,
    '患者记录中不存在任何时间字段（date/month/visitDate），“疾病趋势”“月度患者变化”缺乏数据来源，实为 diseases 总数÷12 反推');
  return '存在时间字段';
});

check('TC-D-10', '同一疾病在不同月份应有真实差异，而非总数/12 的复制', () => {
  const t = md.getMonthlyTrends();
  const series = t.map(x => x['无心脏病']);
  const unique = [...new Set(series)];
  assert(unique.length > 1,
    `“无心脏病”12 个月取值为 [${series.join(',')}]，仅 ${unique.length} 种取值：无真实时间波动，系 baseValue/12 复制`);
  return unique.length + ' 种取值';
});

check('TC-D-11', '热力图取值应随月份变化（app.js initHeatmap 用 count/12）', () => {
  const counts = md.patients.reduce((acc, p) => {
    acc[p.target] = (acc[p.target] || 0) + 1; return acc;
  }, {});
  const row = [];
  for (let m = 0; m < 12; m++) row.push(Math.floor((counts[0] || 0) / 12));
  const unique = [...new Set(row)];
  assert(unique.length > 1,
    `热力图“无心脏病”行 12 格取值恒为 [${row.join(',')}]：整行同色，不代表任何月份差异`);
  return row.join(',');
});

// ---------- 数据完整性 ----------
check('TC-D-12', '关键字段无 null/undefined/NaN', () => {
  const fields = ['age', 'sex', 'trestbps', 'chol', 'thalach', 'target'];
  const bad = [];
  md.patients.forEach((p, i) => {
    fields.forEach(f => {
      const v = p[f];
      if (v === null || v === undefined || (typeof v === 'number' && Number.isNaN(v))) {
        bad.push(`id=${p.id} 字段 ${f}=${v}`);
      }
    });
  });
  assert(bad.length === 0, `发现 ${bad.length} 处异常: ${bad.slice(0, 5).join('; ')}`);
  return `${md.patients.length} 条记录校验通过`;
});

check('TC-D-13', '数值字段在医学合理区间内', () => {
  const bad = [];
  md.patients.forEach(p => {
    if (p.age < 0 || p.age > 120) bad.push(`id=${p.id} age=${p.age}`);
    if (p.trestbps < 60 || p.trestbps > 260) bad.push(`id=${p.id} trestbps=${p.trestbps}`);
    if (p.chol < 0 || p.chol > 700) bad.push(`id=${p.id} chol=${p.chol}`);
    if (p.thalach < 40 || p.thalach > 220) bad.push(`id=${p.id} thalach=${p.thalach}`);
  });
  assert(bad.length === 0, `越界 ${bad.length} 处: ${bad.slice(0, 5).join('; ')}`);
  return '全部在合理区间';
});

check('TC-D-14', 'target 取值仅为 0~4', () => {
  const bad = md.patients.filter(p => ![0, 1, 2, 3, 4].includes(p.target));
  assert(bad.length === 0, `非法 target: ${bad.slice(0, 3).map(p => p.id + '=' + p.target).join(', ')}`);
  return '合法';
});

// ---------- 筛选逻辑（app.js getFilteredData 等价实现） ----------
check('TC-D-15', '按疾病等级筛选结果正确', () => {
  const results = {};
  [0, 1, 2, 3, 4].forEach(lv => {
    results[lv] = md.patients.filter(p => p.target === lv).length;
  });
  const sum = Object.values(results).reduce((a, b) => a + b, 0);
  assert(sum === md.patients.length, `各等级求和 ${sum} != ${md.patients.length}`);
  return JSON.stringify(results);
});

check('TC-D-16', '散点图 slice(0,100) 会截断数据且不提示', () => {
  const all = md.patients.length;
  const shown = Math.min(all, 100);
  const lost = all - shown;
  assert(lost === 0,
    `散点图仅渲染前 ${shown} 条，丢弃 ${lost} 条（${(lost / all * 100).toFixed(0)}%），页面上无“采样/仅显示前N条”说明`);
  return `展示 ${shown}/${all}`;
});

check('TC-D-17', '筛选“危急心脏病”后散点图样本量足够支撑结论', () => {
  const n = md.patients.filter(p => p.target === 4).length;
  assert(n >= 30, `危急心脏病仅 ${n} 例，样本量过小，图表结论不可靠且无提示`);
  return `${n} 例`;
});

// ---------- 幂等性 ----------
check('TC-D-18', '重复调用 init() 不应重复累加趋势数据', () => {
  const before = md.diseaseTrends.length;
  md.init();
  const after = md.diseaseTrends.length;
  assert(before === after, `init() 二次调用后 diseaseTrends 由 ${before} 增至 ${after}，数据被重复追加`);
  return `${before} 条`;
});

console.log(`\n=== 小结：通过 ${pass}，失败 ${fail} ===`);
if (fail) {
  console.log('\n失败用例（对应缺陷报告）：');
  failures.forEach(f => console.log(`  ${f.id} ${f.name}\n      ${f.msg}`));
}
process.exit(fail ? 1 : 0);
