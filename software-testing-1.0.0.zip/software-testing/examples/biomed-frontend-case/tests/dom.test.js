/**
 * 生物医疗大数据分析平台 —— DOM/交互层测试
 * 运行：NODE_PATH=<workspace>/node_modules node tests/dom.test.js
 * 依赖：jsdom（Chart.js 与 canvas 打桩，不联网）
 */
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const SRC = process.env.SRC_DIR
  || 'C:/Users/wjh/Desktop/it文化节/人工智能学院+计算机242+吴杰涵+大数据可视化设计';

const html = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true });
const win = dom.window;
const doc = win.document;

// ---- 打桩：canvas / Chart.js / scrollIntoView ----
win.HTMLCanvasElement.prototype.getContext = () => ({
  canvas: { width: 600, height: 400 },
  clearRect() {}, save() {}, restore() {}, beginPath() {}, measureText: () => ({ width: 10 }),
});
win.__chartInstances = [];
win.Chart = function (ctx, config) {
  this.ctx = ctx;
  this.data = config.data;
  this.options = config.options;
  this.type = config.type;
  this.updateCount = 0;
  this.update = function () { this.updateCount++; };
  win.__chartInstances.push(this);
};
win.Element.prototype.scrollIntoView = function () { win.__lastScrolled = this; };

// ---- 注入被测脚本 ----
// 注意：eval 中的 const/let 是 eval 作用域私有的，不会挂到 window，
// 因此在同一段 eval 末尾显式导出，供后续脚本与断言访问。
function loadScript(file, exports) {
  const code = fs.readFileSync(path.join(SRC, file), 'utf8');
  const tail = exports.map(n => `;window.${n} = ${n};`).join('');
  win.eval(code + tail);
}
loadScript('data.js', ['medicalData', 'heartDiseaseData']);
loadScript('app.js', ['charts', 'currentFilters']);
doc.dispatchEvent(new win.Event('DOMContentLoaded'));

const E = expr => win.eval(expr);

let pass = 0, fail = 0;
const failures = [];
function check(id, name, fn) {
  try {
    const detail = fn();
    pass++;
    console.log(`PASS  ${id}  ${name}${detail ? '  → ' + detail : ''}`);
  } catch (e) {
    fail++;
    failures.push({ id, name, msg: e.message });
    console.log(`FAIL  ${id}  ${name}\n        ${e.message}`);
  }
}
function assert(cond, msg) { if (!cond) throw new Error(msg); }
const click = el => el.dispatchEvent(new win.MouseEvent('click', { bubbles: true }));
const change = el => el.dispatchEvent(new win.Event('change', { bubbles: true }));

const sleep = ms => new Promise(r => setTimeout(r, ms));

console.log('=== DOM / 交互层测试 ===\n');

async function main() {
await sleep(1800);   // 等待统计卡片数字动画（50 步 × 30ms）跑完

check('TC-U-01', '页面加载后仪表板为默认激活页', () => {
  assert(doc.getElementById('dashboard').classList.contains('active'),
    'dashboard 未激活');
  return 'dashboard.active';
});

check('TC-U-02', '四个统计卡片数字均被渲染（非初始 0）', () => {
  const ids = ['totalPatients', 'avgAge', 'diseaseTypes', 'recoveryRate'];
  const vals = ids.map(i => doc.getElementById(i).textContent);
  assert(!vals.includes('0'), `存在未渲染的卡片: ${JSON.stringify(vals)}`);
  return vals.join(' / ');
});

check('TC-U-03', '点击导航可切换到数据分析页', () => {
  click(doc.querySelector('.nav-item[data-page="analysis"]'));
  assert(doc.getElementById('analysis').classList.contains('active'),
    'analysis 页未激活');
  assert(!doc.getElementById('dashboard').classList.contains('active'),
    'dashboard 未取消激活');
  return '切换成功';
});

check('TC-U-04', '首次进入分析页时各图表被创建', () => {
  const n = win.__chartInstances.length;
  assert(n >= 8, `图表实例数 ${n}，期望 ≥8（仪表板4 + 分析页4）`);
  return `${n} 个图表实例`;
});

check('TC-U-05', 'HTML 中不存在重复 id', () => {
  const ids = [...doc.querySelectorAll('[id]')].map(el => el.id);
  const dup = ids.filter((v, i) => ids.indexOf(v) !== i);
  assert(dup.length === 0,
    `重复 id: ${[...new Set(dup)].join(', ')}（<section id="analysis"> 与报告 <article id="analysis"> 冲突）`);
  return `${ids.length} 个 id 均唯一`;
});

check('TC-U-06', '研究报告侧栏“5. 数据分析与实验”锚点指向报告章节', () => {
  const el = doc.getElementById('analysis');
  assert(el.tagName === 'ARTICLE',
    `getElementById('analysis') 命中 <${el.tagName.toLowerCase()}>（页面 section），而非报告 article；锚点跳转失效`);
  return '命中报告章节';
});

check('TC-U-07', '点击报告侧栏导航项能高亮并定位到对应章节', () => {
  const navItems = [...doc.querySelectorAll('.report-nav-item')];
  const target = navItems.find(a => a.getAttribute('href') === '#conclusion');
  click(target);
  assert(target.classList.contains('active'), '点击后导航项未高亮');
  const scrolled = win.__lastScrolled;
  assert(scrolled && scrolled.id === 'conclusion',
    `scrollIntoView 目标为 ${scrolled ? scrolled.id : 'null'}，期望 conclusion`);
  return '高亮 + 定位正确';
});

check('TC-U-08', '切换“疾病严重程度”筛选后散点图与胆固醇图同步刷新', () => {
  const before = E('charts.bpHeartChart.updateCount');
  const sel = doc.getElementById('diseaseFilter');
  sel.value = '4';
  change(sel);
  const after = E('charts.bpHeartChart.updateCount');
  assert(after > before, `散点图未刷新（updateCount ${before} → ${after}）`);
  return `updateCount ${before} → ${after}`;
});

check('TC-U-09', '筛选后散点图点数与筛选结果一致（危急心脏病 14 例）', () => {
  const pts = E('charts.bpHeartChart.data.datasets[0].data.length');
  assert(pts === 14, `散点图渲染 ${pts} 个点，期望 14`);
  return `${pts} 个点`;
});

check('TC-U-10', '切换筛选后热力图同步刷新', () => {
  const cellsBefore = [...doc.querySelectorAll('.heatmap-cell')].map(c => c.textContent).join(',');
  const sel = doc.getElementById('diseaseFilter');
  sel.value = '0';
  change(sel);
  const cellsAfter = [...doc.querySelectorAll('.heatmap-cell')].map(c => c.textContent).join(',');
  assert(cellsBefore !== cellsAfter,
    `热力图未随筛选变化，前后一致（前 20 字符: ${cellsBefore.slice(0, 20)}…）`);
  return '已同步刷新';
});

check('TC-U-11', '热力图取值真实反映月份差异（非整行同值）', () => {
  const cells = [...doc.querySelectorAll('.heatmap-cell')].map(c => c.textContent);
  assert(cells.length === 60, `热力图格子数 ${cells.length}，期望 60（5疾病×12月）`);
  const firstRow = cells.slice(0, 12);
  const uniq = [...new Set(firstRow)];
  assert(uniq.length > 1,
    `第一行 12 格取值恒为 [${firstRow.join(',')}]，整行同色，无月份差异`);
  return `${uniq.length} 种取值`;
});

check('TC-U-12', '切换“时间范围”后月度图同步刷新', () => {
  const before = E('charts.monthlyChart.updateCount');
  const sel = doc.getElementById('timeRange');
  sel.value = '6';
  change(sel);
  const after = E('charts.monthlyChart.updateCount');
  assert(after > before, `月度图未刷新（updateCount ${before} → ${after}）`);
  const labels = E('charts.monthlyChart.data.labels.length');
  assert(labels === 6, `时间范围选 6 个月后，标签数 ${labels}，期望 6`);
  return `标签数 ${labels}`;
});

check('TC-U-13', '主导航项具备键盘可达性（可聚焦元素或 role/tabindex）', () => {
  const items = [...doc.querySelectorAll('.nav-item')];
  const bad = items.filter(el =>
    el.tagName !== 'BUTTON' && el.tagName !== 'A'
    && !el.hasAttribute('tabindex') && !el.hasAttribute('role'));
  assert(bad.length === 0,
    `${bad.length}/${items.length} 个导航项为 <li> 且无 tabindex/role，键盘与读屏无法聚焦操作`);
  return `${items.length} 个导航项均可聚焦`;
});

check('TC-U-14', '关键发现卡片已渲染', () => {
  const cards = doc.querySelectorAll('.insight-card');
  assert(cards.length === 4, `关键发现卡片 ${cards.length} 个，期望 4`);
  return `${cards.length} 张卡片`;
});

check('TC-U-15', '报告中“数据覆盖率 89%”等指标有数据支撑', () => {
  const txt = doc.getElementById('report').textContent;
  const has = ['89%', '12', '5'].every(v => txt.includes(v));
  const stats = E('JSON.stringify(medicalData.getStats())');
  assert(!has || /89%/.test(stats),
    `报告写死指标（数据覆盖率 89%、分析维度 12、预测模型 5），而 getStats() 返回 ${stats}，无法对应`);
  return '指标与数据可对应';
});

  console.log(`\n=== 小结：通过 ${pass}，失败 ${fail} ===`);
  if (fail) {
    console.log('\n失败用例（对应缺陷报告）：');
    failures.forEach(f => console.log(`  ${f.id} ${f.name}\n      ${f.msg}`));
  }
  process.exit(fail ? 1 : 0);
}

main();
