---
name: software-testing
description: 软件测试全流程工程能力——需求可测试性评估、测试计划与策略、测试用例设计（等价类/边界值/判定表/场景法/状态迁移/错误推测）、pytest 自动化测试脚本生成、缺陷报告编写、测试报告汇总。当用户提到软件测试、测试用例、测试计划、测试策略、自动化脚本、pytest、接口测试、API 测试、UI 测试、Playwright、回归测试、冒烟测试、覆盖率、缺陷/Bug 报告、测试报告，或要求为某个功能/接口/模块/代码设计测试方案、找 bug、评估质量风险时使用本 skill。默认技术栈 Python + pytest。
description_en: End-to-end software testing engineering — testability review, test plan and strategy, test case design (equivalence partitioning, boundary value, decision table, scenario, state transition, error guessing), pytest automation scaffolding, defect reports, and test summary reports. Use when the user asks to test a feature/module/API/web page, design test cases, write pytest automation, file a bug report, or assess quality risk. Ships ready-to-run scripts, four deliverable templates, and a Node+jsdom path for pure frontend projects.
description_zh: 软件测试全流程：可测试性评估、测试计划、用例设计、pytest 自动化、缺陷报告、测试报告。
version: 1.0.0
license: MIT
agent_created: true
---

# 软件测试全流程

## Overview

把软件测试从"拍脑袋写几条用例"变成可复现的工程流程：先确认需求可测试、再做策略与计划、按方法设计用例、把稳定用例沉淀为 pytest 自动化代码、执行后输出规范缺陷与报告。

核心原则：**先问清需求边界再动手，用方法保证覆盖而非靠灵感，用例必须可判定可复现，能自动化的尽量自动化。**

## 触发路由

先判断用户要哪一段，再加载对应资源，不要一次性全做：

| 用户的诉求 | 走哪个工作流 | 必读资源 |
|---|---|---|
| "帮我测一下 X"/"看看这段代码有什么问题" | W1 + W3 + W5 | `references/checklists.md`、`references/test-design-techniques.md` |
| "测一下这个网页/HTML/前端项目" | W1 + W3 + W5，脚本用 Node + jsdom | `references/frontend-testing.md`、`references/checklists.md` |
| "写测试计划/测试策略" | W2 | `assets/test_plan_template.md`、`references/checklists.md` |
| "设计测试用例"/"写用例" | W3 | `references/test-design-techniques.md`、`assets/test_case_template.md` |
| "写自动化测试代码"/"pytest 脚本" | W4 | `references/pytest-guide.md`、`scripts/scaffold_pytest.py` |
| "这个 bug 怎么提"/"帮我写缺陷报告" | W5 | `references/defect-and-severity.md`、`assets/defect_report_template.md` |
| "出测试报告"/"总结一下测试结果" | W6 | `assets/test_report_template.md`、`references/defect-and-severity.md` |
| 完整版本测试（提测） | W1→W2→W3→W4→W5→W6 顺序执行 | 全部 |

## 通用铁律

1. **先确认边界再设计**：需求/接口文档缺失或含糊时，先用「可测试性质疑清单」（`references/checklists.md` 第九节）列出待确认问题，给出自己的合理假设并标注，不要因为等待而停滞。
2. **一条用例验证一个点**，预期结果必须可判定（具体状态码、字段值、库表值），禁止"正常显示"这类表述。
3. **用例互斥独立**：不依赖执行顺序，数据用 fixture 造并清理。
4. **覆盖优先于数量**：按覆盖度矩阵自查补齐，而不是堆砌重复用例。
5. **不谎报执行结果**：无法真实运行测试（无环境、无依赖）时，明确说明"未实际执行"，不要编造通过率。
6. **所有产出落到文件**，不要只在对话里输出大段表格；文件命名见「输出规范」。
7. **技术栈不匹配时降级**：被测对象没有 Python 入口（纯前端静态页、Node 项目）时，不要硬套 pytest，改用 Node + jsdom 驱动（见 `references/frontend-testing.md`）；凡依赖布局/真实渲染的断言（滚动高亮、可见性、响应式），jsdom 验证不了，必须标注"未实际执行"并转人工或 Playwright。

## W1 需求/代码可测试性评估

1. 通读需求文档、接口文档或源码，梳理：功能点、输入参数、业务规则、状态机、数据流、依赖方。
2. 逐条过 `references/checklists.md` 第九节「可测试性质疑清单」，输出**待确认问题清单**（含影响的测试点）。
3. 识别风险区：金额/库存/并发/权限/异步回调/老数据兼容，标为高风险。
4. 输出：功能点清单 + 待确认问题 + 风险区 + 建议的测试深度。

## W2 测试计划与策略

1. 复制 `assets/test_plan_template.md` 到目标目录，按字段填充。
2. 明确**在范围内/不在范围内**，以及回归范围（改动影响面分析）。
3. 定策略：哪些手工、哪些自动化、哪些纳入 CI 冒烟门禁。
4. 写死准入/准出标准（冒烟 100% 通过才进系统测试；S1/S2 清零才发布）。
5. 列出环境、账号、造数方案、第三方 Mock 方案与风险应对。

## W3 测试用例设计

1. 按功能点选择设计方法（见 `references/test-design-techniques.md`）：
   - 输入有范围 → 等价类 + 边界值
   - 多条件组合 → 判定表（组合爆炸改 pairwise）
   - 端到端链路 → 场景法（基本流 + 备选流 + 异常流）
   - 有状态机 → 状态迁移（合法迁移 + 非法迁移）
   - 补刀 → 错误推测法（弱网、并发、时区、emoji、金额精度、重复点击）
2. 用 `assets/test_case_template.md` 的表格结构产出，字段齐全（ID/模块/标题/前置/步骤/数据/预期/优先级/类型/方法/需求）。
3. 用例编号 `TC-<模块>-<三位序号>`，优先级 P0~P3 按定义判定。
4. 用「覆盖度矩阵」自查：参数正/负/边界、接口异常分支（401/403/404/500/超时）、幂等与并发、权限矩阵、列表空/单/满/越界，缺什么补什么。
5. 交付时若用户要 Excel，执行 `scripts/cases_to_xlsx.py`：

```bash
python scripts/cases_to_xlsx.py 用例集.md -o 用例集.xlsx
```

每个 Markdown 表格生成一个 sheet，sheet 名取自最近的标题；未装 `openpyxl` 时自动降级为 CSV。

## W4 自动化测试脚本

默认走 pytest（`references/pytest-guide.md`）；被测对象是纯前端静态页时改走 Node + jsdom（`references/frontend-testing.md`）。

1. 首次为项目搭建测试工程时，先跑脚手架，再在其上改：

```bash
python scripts/scaffold_pytest.py --dir ./autotest --type api   # api | ui | both
```

生成 `pytest.ini`、`conftest.py`（鉴权 fixture）、`utils/client.py`、`utils/assert_util.py`、示例用例与 README。已存在的文件默认不覆盖，需要覆盖加 `--force`。

2. 编写规范严格遵循 `references/pytest-guide.md`：目录结构、fixture 分层、参数化数据驱动、分层断言（HTTP→业务码→结构→DB）、接口七大必测维度、UI 用 `expect()` 自动等待。
3. 覆盖策略：P0 与稳定回归用例进 `smoke` 标记纳入 CI；体验类、一次性验证不自动化。
4. 环境配置走环境变量，禁止硬编码域名、账号、密钥。
5. 写完后做静态验证：`pytest --collect-only -q` 确认可收集；若环境依赖齐全则真实执行并给出结果，否则明确说明未执行及原因。

## W5 缺陷报告

1. 判定等级与优先级（S1~S4 / P1~P4，见 `references/defect-and-severity.md`），并写一句判定理由。
2. 按 `assets/defect_report_template.md` 填充，重点保证**最小复现路径**与**证据完整**（响应体、日志、截图、traceId）。
3. 一个缺陷一份报告；偶发缺陷必须写明频率与触发条件。
4. 提交前过一遍「常见被拒原因」自检清单。
5. 若用户给了源码，尽量补充初步根因线索（模块/代码行/配置），但不确定时注明是推测。

## W6 测试报告

1. 复制 `assets/test_report_template.md`，填执行数据（执行率/通过率/P0 通过率）、缺陷分级统计与趋势、专项结论（性能 p95、安全、兼容、回归）。
2. 做根因分布分析，并给**可执行改进建议**（流程、工具、用例沉淀），而不只是罗列数字。
3. 给出明确发布建议：建议发布 / 有条件发布（列条件）/ 不建议发布，对齐 W2 的准出标准。
4. 遗留缺陷必须带影响面、绕行方案、计划修复版本。

## 输出规范

| 交付物 | 建议路径 | 模板 |
|---|---|---|
| 测试计划 | `docs/test-plan-<版本>.md` | `assets/test_plan_template.md` |
| 用例集 | `docs/test-cases-<模块>.md`（可转 `.xlsx`） | `assets/test_case_template.md` |
| 自动化代码 | `autotest/` 工程目录 | `scripts/scaffold_pytest.py` |
| 缺陷报告 | `docs/bugs-<版本>.md` | `assets/defect_report_template.md` |
| 测试报告 | `docs/test-report-<版本>.md` | `assets/test_report_template.md` |

产出完成后用 `present_files` 展示文件，并在回复中给出关键结论（用例数、覆盖缺口、风险项、发布建议），不要只说"已生成"。

## 资源清单

### scripts/
- `scaffold_pytest.py` — 初始化 pytest 工程骨架（api/ui/both），含 conftest、client、断言工具、示例用例
- `cases_to_xlsx.py` — Markdown 用例表转 Excel（多表格多 sheet，无 openpyxl 时降级 CSV）

### references/
- `test-design-techniques.md` — 用例设计七大方法、字段规范、优先级定义、覆盖度矩阵
- `pytest-guide.md` — 目录结构、fixture、参数化、断言、接口/UI 实践、执行命令、flaky 治理、多语言对照
- `frontend-testing.md` — 纯前端/无 Python 入口时的 Node + jsdom 测试路径：脚手架、eval 作用域坑、动画等待、前端重点测试点
- `defect-and-severity.md` — 缺陷分级与优先级、状态流转、报告要素、RCA 归类、被拒自检
- `checklists.md` — 九大类测试点清单（功能/边界异常/并发幂等/权限安全/数据一致性/兼容/性能/可观测/需求质疑）

### assets/
- `test_case_template.md`、`test_plan_template.md`、`test_report_template.md`、`defect_report_template.md` — 四类交付物模板，含填充示例

### examples/
- `biomed-frontend-case/` — 真实项目完整测试案例（35 用例 / 12 缺陷），含可直接 `node` 运行的测试脚本；纯前端走 Node+jsdom 路径时以此为参照

### 包内说明文件
- `README.md` — 使用者说明（能力、触发词、安装、案例）
- `SECURITY.md` — 两个脚本的安全自检结论（无网络、无凭证、无代码执行）
- `CHANGELOG.md` — 版本记录与已知限制
