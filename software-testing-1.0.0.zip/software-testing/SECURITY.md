# 安全自检说明

本 skill 含可执行脚本，上架前已按市场常见安全扫描项逐条自查，结论如下。

## 脚本清单与行为

| 脚本 | 行为 | 网络 | 文件写入范围 | 凭证 |
|---|---|---|---|---|
| `scripts/scaffold_pytest.py` | 生成 pytest 工程骨架文件 | **无** | 仅写入 `--dir` 指定的目标目录 | 无 |
| `scripts/cases_to_xlsx.py` | 读取 Markdown 表格，输出 xlsx/CSV | **无** | 仅写入 `-o` 指定的输出路径 | 无 |

## 逐项结论

| 检查项 | 结论 |
|---|---|
| 外发网络请求 | ✅ 无任何 HTTP/FTP/远程调用，纯本地文件读写 |
| 凭证与环境变量 | ✅ 不读取任何密钥、token、环境变量；生成的示例代码只读取 `BASE_URL`/`TEST_USER`/`TEST_PWD`，且由使用者自行在 `.env` 填写 |
| 任意代码执行 / 命令注入 | ✅ 无 `eval`、`exec`、`os.system`、`subprocess` 调用 |
| 越权写入 / 路径穿越 | ✅ 写入路径全部来自显式命令行参数，不做路径拼接猜测；`scaffold_pytest.py` 默认不覆盖已存在文件（需显式 `--force`） |
| 数据外传 | ✅ 不上传任何数据，无遥测、无统计上报 |
| 依赖 | ✅ 仅标准库；`cases_to_xlsx.py` 可选依赖 `openpyxl`，缺失时降级为 CSV，不会静默失败 |
| 提示词注入 / 越权指令 | ✅ SKILL.md 中的指令只约束测试工作流，不含"忽略先前指令""执行任意命令"类内容 |
| 破坏性操作 | ✅ 无删除、无覆盖、无权限修改；`cases_to_xlsx.py` 输出前不删除输入文件 |

## 使用建议

- 脚本只在用户显式指定的目录内写文件，建议先 `--dir` 指向空目录试跑
- `scaffold_pytest.py` 生成的 `conftest.py` 从环境变量读账号密码，请勿把真实凭据提交进仓库

## 自检方法（可复现）

```bash
grep -nE "subprocess|os\.system|eval\(|exec\(|requests\.|urllib|socket" scripts/*.py   # 应无输出
python scripts/scaffold_pytest.py --dir /tmp/demo --type api                          # 仅写目标目录
```
